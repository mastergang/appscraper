create FUNCTION          "FN_LASTDAY" ( as_date in char ) return char is 
    lastday varchar2(08) := NULL; 
begin 
    select to_char(to_date(as_date,'yyyymmdd')-1,'yyyymmdd') lastday 
    INTO lastday 
    from dual; 
 
RETURN lastday; 
 
exception 
when others then 
 return '-1'; 
end;

/

