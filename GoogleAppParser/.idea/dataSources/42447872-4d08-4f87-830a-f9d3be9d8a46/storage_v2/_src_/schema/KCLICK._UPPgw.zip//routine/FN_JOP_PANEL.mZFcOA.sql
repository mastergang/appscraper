create FUNCTION          "FN_JOP_PANEL" ( as_code in char ) return char is 
    job_name varchar2(20):= NULL; 
begin 
select code_name 
into job_name 
from tb_codebook 
where meta_code = 'JOB' 
and code = as_code; 
if job_name is null then 
job_name := as_code; 
end if; 
return job_name; 
exception 
when others then 
return '기타'; 
end;

/

