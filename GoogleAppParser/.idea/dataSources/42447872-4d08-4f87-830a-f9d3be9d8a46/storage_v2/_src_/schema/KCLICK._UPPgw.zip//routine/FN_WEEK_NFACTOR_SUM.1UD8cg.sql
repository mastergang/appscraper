create FUNCTION          "FN_WEEK_NFACTOR_SUM" ( as_weekcode in char ) return char is 
    total_nfactor number; 
begin 
    select sum(kc_n_factor) 
    into total_nfactor 
    from tb_panel_seg 
    where weekcode = as_weekcode; 
 
return total_nfactor; 
 
exception 
when others then 
    return '-1'; 
end;

/

