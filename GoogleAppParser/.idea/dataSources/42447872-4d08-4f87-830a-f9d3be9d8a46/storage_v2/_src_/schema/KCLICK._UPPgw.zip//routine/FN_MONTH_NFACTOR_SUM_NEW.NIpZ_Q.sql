create FUNCTION          "FN_MONTH_NFACTOR_SUM_NEW" ( as_monthcode in char ) return char is   
nfactor number;   
begin   
    select sum(kc_n_factor)  
    into nfactor   
    from tb_month_panel_seg  
    where monthcode = as_monthcode 
    and panel_id in ( select panel_id from tb_month_loc_panel_seg where   monthcode = as_monthcode and loc_cd != 4 group by panel_id); 
 
return nfactor;   
   
exception   
when others then   
    return '-1';   
end;

/

