create FUNCTION          "FN_RETURN_PATTERN" (full_url IN CHAR) RETURN CHAR IS 
BEGIN 
    IF full_url LIKE '%^' THEN 
        RETURN SUBSTR(full_url, 1, -1); 
    END IF; 
 
RETURN full_url || '%'; 
 
EXCEPTION 
WHEN OTHERS THEN 
    RETURN full_url || '%'; 
END;

/

