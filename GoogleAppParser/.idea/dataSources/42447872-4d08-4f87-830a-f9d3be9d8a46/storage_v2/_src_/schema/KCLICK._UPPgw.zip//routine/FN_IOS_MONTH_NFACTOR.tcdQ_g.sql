create FUNCTION "FN_IOS_MONTH_NFACTOR" ( as_monthcode in char ) return char is   
    nfactor number;   
begin   
    if as_monthcode < 201110 then nfactor:=-1; 
    else 
        select NETIZEN_CNT into nfactor   
        from tb_ios_month_netizen_cnt 
        where monthcode = as_monthcode; 
    end if; 
return nfactor; 
   
exception   
when others then   
    return '-1';   
end;
/

