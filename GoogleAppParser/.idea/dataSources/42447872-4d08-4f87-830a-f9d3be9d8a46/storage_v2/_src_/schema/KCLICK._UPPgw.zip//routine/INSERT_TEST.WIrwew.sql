create PROCEDURE Insert_Test
     is 
     begin

  
		INSERT INTO TEMP_SHIN_CALCULATION_COMPARE3
		SELECT a.device_cd, a.psex_cls, a.page_cls, a.pregion_cd, a.aage_cls, a.asex_cls, a.aregion_cd, a.iage_cls, a.isex_cls, a.iregion_cd, 
		    a.m_sex_cls, a.m_age_cls, a.m_region_cd, a.location, a.atelecom, a.itelecom, a.netizen_cnt, b.weight, round(b.weight) round_weight
		FROM
		(
		    SELECT device_cd, psex_cls, page_cls, pregion_cd, aage_cls, asex_cls, aregion_cd, iage_cls, isex_cls, iregion_cd, m_sex_cls, m_age_cls, m_region_cd, 
			null location, null atelecom, null itelecom, sum(netizen_cnt) netizen_cnt
		    FROM   TEMP_KWHSIN_ALL_NETIZEN 
		    WHERE  exp_time > sysdate 
		    and    ef_time < sysdate  
		    group by grouping sets((psex_cls, page_cls, pregion_cd), (aage_cls, asex_cls, aregion_cd), (iage_cls, isex_cls, iregion_cd), (m_sex_cls, m_age_cls, m_region_cd),device_cd)
		    union all
		    select null device_cd, null psex_cls, null page_cls, null pregion_cd, null aage_cls, null asex_cls, null aregion_cd, null iage_cls, null isex_cls, null iregion_cd, null m_sex_cls, 
			null m_age_cls, null m_region_cd, location, null atelecom, null itelecom, netizen_cnt
		    from temp_kwshin_loc_netizen
		    union all
		    select null device_cd, null psex_cls, null page_cls, null pregion_cd, null aage_cls, null asex_cls, null aregion_cd, null iage_cls, null isex_cls, null iregion_cd, null m_sex_cls, 
			null m_age_cls, null m_region_cd, null location, telecom_cd atelecom, null itelecom, netizen_cnt
		    from temp_kwshin_telecom_netizen
		    union all
		    select null device_cd, null psex_cls, null page_cls, null pregion_cd, null aage_cls, null asex_cls, null aregion_cd, null iage_cls, null isex_cls, null iregion_cd, null m_sex_cls, 
			null m_age_cls, null m_region_cd, null location, null atelecom, telecom_cd itelecom, netizen_cnt
		    from TEMP_KWSHIN_IOS_TEL_NETIZEN
		) a,
		(
		    SELECT device_cd, psex_cls, page_cls, pregion_cd, aage_cls, asex_cls, aregion_cd, iage_cls, isex_cls, iregion_cd, m_sex_cls, m_age_cls, m_region_cd, 
			location, decode(device_cd,'20','50','40','50','50','50',telecom_cd) atelecom, decode(device_cd,'10','50','20','50','30','50',telecom_cd)  itelecom, sum(n_weight) weight
		    FROM   temp_kwshin_calcul_weight_a
		    group by grouping sets((psex_cls, page_cls, pregion_cd), (aage_cls, asex_cls, aregion_cd), (iage_cls, isex_cls, iregion_cd), (m_sex_cls, m_age_cls, m_region_cd),
			device_cd,location, decode(device_cd,'20','50','40','50','50','50',telecom_cd), decode(device_cd,'10','50','20','50','30','50',telecom_cd) )
		) b
		WHERE nvl(a.device_cd,'0')=nvl(b.device_cd,'0')
		and nvl(a.psex_cls,'0')=nvl(b.psex_cls,'0')
		and nvl(a.page_cls,'0')=nvl(b.page_cls,'0')
		and nvl(a.pregion_cd,'0')=nvl(b.pregion_cd,'0')
		and nvl(a.aage_cls,'0')=nvl(b.aage_cls,'0')
		and nvl(a.asex_cls,'0')=nvl(b.asex_cls,'0')
		and nvl(a.aregion_cd,'0')=nvl(b.aregion_cd,'0')
		and nvl(a.iage_cls,'0')=nvl(b.iage_cls,'0')
		and nvl(a.isex_cls,'0')=nvl(b.isex_cls,'0')
		and nvl(a.iregion_cd,'0')=nvl(b.iregion_cd,'0')
		and nvl(a.m_sex_cls,'0')=nvl(b.m_sex_cls,'0')
		and nvl(a.m_age_cls,'0')=nvl(b.m_age_cls,'0')
		and nvl(a.m_region_cd,'0')=nvl(b.m_region_cd,'0')
		and nvl(a.location,'0')=nvl(b.location,'0')
		and nvl(a.atelecom,'0')=nvl(b.atelecom,'0')
		and nvl(a.itelecom,'0')=nvl(b.itelecom,'0')
		and round(netizen_cnt)=round(weight)
         ;
         
         commit;
		  

     END ;

/

