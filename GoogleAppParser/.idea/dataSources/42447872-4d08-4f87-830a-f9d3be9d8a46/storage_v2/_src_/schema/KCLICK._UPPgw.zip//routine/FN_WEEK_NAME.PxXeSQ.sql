create FUNCTION          "FN_WEEK_NAME" ( as_code in char ) return char is 
    week_name varchar2(20):= NULL; 
begin 
    select START_DATE||'~'||END_DATE 
    into week_name 
    from tb_week_cat 
    where weekcode = as_code; 
 
if week_name is null then 
    week_name := as_code; 
end if; 
 
return week_name; 
 
exception 
when others then 
    return as_code; 
end;

/

