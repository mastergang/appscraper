create FUNCTION          "FN_REGION_NAME" ( as_code in char ) return char is 
    region_name varchar2(30):= NULL; 
begin 
    select code_name 
    into region_name 
    from tb_codebook 
    where meta_code = 'REGION' 
    and code = as_code; 
 
if region_name is null then 
    region_name := as_code; 
end if; 
 
return region_name; 
 
exception 
when others then 
    return as_code; 
end;

/

