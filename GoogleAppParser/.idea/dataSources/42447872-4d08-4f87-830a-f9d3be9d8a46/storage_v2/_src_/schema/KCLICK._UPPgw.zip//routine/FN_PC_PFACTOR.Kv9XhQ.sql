create FUNCTION        "FN_PC_PFACTOR" ( as_sex_cls in char, as_age_cls in char, as_loc_cd in char, as_accessday in char ) return char is  
    weight number;  
begin  
    select PC_WEIGHT   
    into weight  
    from TB_PANEL_WEIGHT   
    where sex_cls = as_sex_cls 
    and   age_cls = as_age_cls 
    and   loc_cd  = as_loc_cd 
    and   exp_time >= to_date(as_accessday,'yyyymmdd') 
    and   ef_time  <= to_date(as_accessday,'yyyymmdd');  
  
return weight;  
  
exception  
when others then  
    return '-1';  
end;
/

