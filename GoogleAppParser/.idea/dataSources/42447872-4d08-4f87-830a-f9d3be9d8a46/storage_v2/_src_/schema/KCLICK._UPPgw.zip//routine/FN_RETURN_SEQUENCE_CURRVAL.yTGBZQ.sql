create FUNCTION        "FN_RETURN_SEQUENCE_CURRVAL" RETURN NUMBER IS  
    return_val NUMBER(20):=NULL; 
BEGIN 
    select temp_yjseo.currval 
    into return_val 
    from dual 
    ;
 
return return_val; 
 
exception 
when others then 
    return return_val; 
end;

--CREATE OR REPLACE FUNCTION KCLICK.FN_RETURN_SEQUENCE_NEXTVAL RETURN NUMBER IS  
--    return_val NUMBER(20):=NULL; 
--BEGIN 
--    select temp_yjseo.NEXTVAL 
--    into return_val 
--    from dual 
--    ;
-- 
--return return_val; 
-- 
--exception 
--when others then 
--    return return_val; 
--end;
/

