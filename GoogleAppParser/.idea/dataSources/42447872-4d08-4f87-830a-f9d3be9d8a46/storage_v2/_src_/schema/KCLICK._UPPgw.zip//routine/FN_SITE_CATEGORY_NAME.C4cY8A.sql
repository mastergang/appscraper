create FUNCTION          "FN_SITE_CATEGORY_NAME" (as_code in char) return char is 
    t_code_name varchar2(50); 
begin 
    select fn_category_ref1_name(category_code1) 
    into t_code_name 
    from tb_site_info 
    where site_id = as_code 
    and exp_time > sysdate; 
 
return t_code_name; 
 
end;

/

