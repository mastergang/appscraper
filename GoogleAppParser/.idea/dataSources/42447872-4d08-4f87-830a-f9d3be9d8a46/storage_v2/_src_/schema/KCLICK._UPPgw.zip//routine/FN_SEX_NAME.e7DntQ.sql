create FUNCTION          "FN_SEX_NAME" ( as_code in char ) return char is 
    sex_name varchar2(20):= NULL; 
begin 
    select code_name 
    into sex_name 
    from tb_codebook 
    where meta_code = 'KC_SEX_CLS' 
    and code = as_code; 
 
if sex_name is null then 
    sex_name := as_code; 
end if; 
 
return sex_name; 
 
exception 
when others then 
    return as_code; 
end;

/

