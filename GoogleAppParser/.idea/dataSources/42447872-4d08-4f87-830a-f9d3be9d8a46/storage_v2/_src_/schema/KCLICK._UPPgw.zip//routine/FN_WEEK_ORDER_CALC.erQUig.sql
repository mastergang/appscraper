create FUNCTION          "FN_WEEK_ORDER_CALC" ( as_date in char ) return number is
    r_week_order number(02) := 0;
    prev_year_date char(08) := NULL;
    day_no number; /* 해당년도에 몇일째인지 */
    d_no number; /* 해당년도의 시작일은 몇요일에서 시작되었는지 */
                 /* ( 일요일:1... 토요일:7) */
    rest_no number;
begin
    day_no := to_number(to_char(to_date(as_date,'yyyymmdd'),'ddd'));
    d_no := to_number(to_char(to_date(
    substr(as_date,1,4)||'0101','yyyymmdd'),'d'));
    /* rest_no : 해당년도에서 첫째주를 시작하기 이전의 일자 */

    if d_no = 2 then /* 월요일로 시작하는 해이면 */
        rest_no := 0;
    elsif d_no = 1 then /* 일요일로 시작한는 해이면 */
        rest_no := 1;
    else
        rest_no := 8 - d_no + 1;
    end if;

    /*해당이리자가 첫째주 시작이전의 일자이면 week_order = 0 */
    /*아니면 해당일을 7로나눈 값의 올림 정수값 */
    if day_no <= rest_no then
        r_week_order := 0;
    else
        r_week_order := ceil((day_no - rest_no) / 7);
    end if;

    /*해당일자의 week_order가 0이면 전년도의 마지막째주에 해당하는 */
    /* Week_order값을 구한다. */
    if r_week_order = 0 then
        prev_year_date := to_char(to_number(substr(as_date,1,4))-1)||'1231';
        r_week_order := fn_week_order_calc(prev_year_date);
    end if;
    
return r_week_order;

exception
when others then
    return -1;
end;

/

