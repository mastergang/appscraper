create trigger TG_PANEL_UPDATE
    after update
    on TB_PANEL
    for each row
BEGIN
  if(:new.panel_status_cd!=:old.panel_status_cd) then
    if(:new.panel_status_cd='CRQ') then
	  insert into tb_panel_crq (panel_id, crq_code, crq_date)
	  values (:new.panelid, '', sysdate);
	elsif(:old.panel_status_cd='CRQ') then
	  delete from tb_panel_crq
	  where panel_id=:new.panelid;
	end if;
  end if;
END;
/

