create view VI_DOMAIN_INFO as
select  DOMAIN_URL,
        SITE_ID,
        EF_TIME,
        EXP_TIME,
        SECTION_ID
from    tb_domain_info
where   sysdate >= ef_time
and     sysdate <= exp_time

/

