create FUNCTION          "FN_SECTION_NAME" ( as_section_id in char ) return char is 
    section_name varchar2(30); 
begin 
    select min(code_name) 
    into section_name 
    from tb_codebook 
    where meta_code in ('SECTION','1ST_SECTION') 
    and code = as_section_id; 
 
return section_name; 
 
exception 
when others then 
    return null; 
end;

/

