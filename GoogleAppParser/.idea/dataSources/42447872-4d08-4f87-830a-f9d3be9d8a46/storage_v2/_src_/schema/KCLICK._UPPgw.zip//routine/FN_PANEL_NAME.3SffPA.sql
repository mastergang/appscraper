create FUNCTION          "FN_PANEL_NAME" ( as_code in char ) return char is 
    panel_name varchar2(20):= NULL; 
begin 
    select name 
    into panel_name 
    from tb_panel 
    where panelid = as_code; 
 
if panel_name is null then 
    panel_name := as_code; 
end if; 
 
return panel_name; 
 
exception 
when others then 
    return as_code; 
end;

/

