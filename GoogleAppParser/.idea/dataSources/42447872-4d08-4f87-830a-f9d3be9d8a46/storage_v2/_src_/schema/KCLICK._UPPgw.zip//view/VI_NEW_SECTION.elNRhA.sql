create view VI_NEW_SECTION as
select  a.code_id,
        a.member_id,
        a.section_id,
        a.section_name,
        b.section_id level2_section_id,
        b.section_name level2_section_name,
        c.section_id level1_section_id,
        c.section_name level1_section_name
from 
(
    select code_id, member_id, section_id, max(section_name) section_name, parent
    from tbc_new_section
    where exp_time >= sysdate
    and depth_level = 3
    group by code_id, member_id, section_id, parent
) a,
(
    select  member_id,
            code_id,
            section_id ,
            section_name ,
            parent
    from tbc_new_section
    where exp_time >= sysdate
    and depth_level = 2
) b,
(
    select  member_id,
            code_id,
            section_id ,
            section_name
    from tbc_new_section
    where exp_time >= sysdate
    and depth_level = 1
) c
where a.parent = b.section_id
and b.parent = c.section_id
and a.member_id = b.member_id
and b.member_id = c.member_id
and a.code_id = b.code_id
and b.code_id = c.code_id

/

