create FUNCTION        "FN_RETURN_PAGE_PATTERN" (full_url IN CHAR) RETURN CHAR IS 
BEGIN 
    RETURN fn_return_pattern(fn_return_page(full_url)); 
END;
/

