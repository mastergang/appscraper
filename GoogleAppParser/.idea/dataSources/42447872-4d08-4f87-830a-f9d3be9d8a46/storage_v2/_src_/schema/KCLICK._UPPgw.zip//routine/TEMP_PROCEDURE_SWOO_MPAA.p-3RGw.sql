create PROCEDURE        temp_procedure_swoo_mpaa  
 
BEGIN  
    --DBMS_OUTPUT.ENABLE;  
      
    SELECT *  
    --INTO v_raw_complete.query_decode  
    from tb_raw_complete  
    where access_day between '20170901'and '20170901' and panel_id='1004seo';  
      
END ;  
  
--set severoutput ON;  
--EXECUTE temp_procedure_swoo_mpaa();
/

