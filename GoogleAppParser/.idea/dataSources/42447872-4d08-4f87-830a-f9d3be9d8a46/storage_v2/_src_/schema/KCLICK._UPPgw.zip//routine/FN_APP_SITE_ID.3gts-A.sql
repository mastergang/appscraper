create FUNCTION          "FN_APP_SITE_ID" ( al_app_id in number ) return number 
is 
    my_site_id number; 
begin 
    select site_id into my_site_id from tb_app_info 
    where app_id = al_app_id 
    and exp_time >= sysdate; 
 
return my_site_id; 
 
end;

/

