create procedure report_month_insert(p_monthcode IN varchar2)
IS

BEGIN

for table_list in 
(
     select table_name From user_all_tables@kcred3 where TABLE_NAME like '%TB_MONTH%' and TABLE_NAME not like '%DNSHOP%'
)
loop
     DBMS_OUTPUT.put_line( table_list.table_name||'@kcred3');
 --    DBMS_OUTPUT.put_line( '************');
     delete from table_list.table_name@kcred3 where monthcode = p_monthcode;
    -- insert into table_list.table_name@kcred3 select * from table_list.table_name where monthcode = p_monthcode;
end loop;
commit;

end;
/

