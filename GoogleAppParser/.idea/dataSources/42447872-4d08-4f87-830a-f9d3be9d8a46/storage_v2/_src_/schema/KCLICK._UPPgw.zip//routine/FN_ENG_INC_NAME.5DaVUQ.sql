create FUNCTION          "FN_ENG_INC_NAME" ( as_code in char ) return char is 
    inc_name varchar2(50):= NULL; 
begin 
    select code_etc 
    into inc_name 
    from tb_codebook 
    where meta_code = 'KC_INC_CLS' 
    and code = as_code; 
 
if inc_name is null then 
    inc_name := as_code; 
end if; 
 
return inc_name; 
 
exception 
when others then 
    return as_code; 
end;

/

