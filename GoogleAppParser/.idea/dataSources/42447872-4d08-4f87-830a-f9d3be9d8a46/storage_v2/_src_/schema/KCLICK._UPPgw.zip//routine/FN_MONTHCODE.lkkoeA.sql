create FUNCTION          "FN_MONTHCODE" ( as_date in char ) 
RETURN CHAR IS
    monthcode number;
    
    length_Err EXCEPTION;
BEGIN

    IF length(as_date) != 8 THEN
         RAISE length_err;
    END IF;

    monthcode := substr(as_date,1,6);
    
    IF substr(as_date,5,2) > 12 THEN
         RAISE length_err;
    ELSIF substr(as_date,5,2) < 1 THEN
         RAISE length_err;
    END IF;
    
    RETURN monthcode;
EXCEPTION
 WHEN length_err THEN
	raise_application_error (-20001,'FN_MONTHCODE의 매개변수가 잘못되었습니다.');
 WHEN OTHERS THEN
	 return '-1';
end;

/

