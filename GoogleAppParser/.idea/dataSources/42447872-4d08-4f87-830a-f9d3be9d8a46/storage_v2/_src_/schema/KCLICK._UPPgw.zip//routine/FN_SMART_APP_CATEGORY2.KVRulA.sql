create FUNCTION        "FN_SMART_APP_CATEGORY2" ( AL_APP_CATEGORY_CD in varchar, as_date in char ) return char is   
    APP_CATEGORY_NAME varchar(100) := NULL;   
begin   
    select APP_CATEGORY_NAME   
    into APP_CATEGORY_NAME   
    from ( 
        select APP_CATEGORY_CD1 CATE_CD, APP_CATEGORY_NAME from TB_SMART_APP_CATEGORY_CD1 where exp_time > to_date(as_date,'yyyymmdd') and ef_time < to_date(as_date,'yyyymmdd')+1
        union all 
        select APP_CATEGORY_CD2 CATE_CD, APP_CATEGORY_NAME from TB_SMART_APP_CATEGORY_CD2 where exp_time > to_date(as_date,'yyyymmdd') and ef_time < to_date(as_date,'yyyymmdd')+1
    ) 
    where CATE_CD = AL_APP_CATEGORY_CD;   
   
return APP_CATEGORY_NAME;   
   
end;
/

