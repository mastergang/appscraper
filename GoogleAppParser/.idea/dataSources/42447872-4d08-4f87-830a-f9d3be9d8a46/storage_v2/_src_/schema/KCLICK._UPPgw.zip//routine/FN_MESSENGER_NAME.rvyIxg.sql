create FUNCTION          "FN_MESSENGER_NAME" ( as_code in char ) return char is 
    messenger_name varchar2(20):= NULL; 
begin 
    select code_name 
    into messenger_name 
    from tb_codebook 
    where meta_code = 'MESSENGER' 
    and code = as_code; 
 
if messenger_name is null then 
    messenger_name := as_code; 
end if; 
 
return messenger_name; 
 
exception 
when others then 
    return as_code; 
end;

/

