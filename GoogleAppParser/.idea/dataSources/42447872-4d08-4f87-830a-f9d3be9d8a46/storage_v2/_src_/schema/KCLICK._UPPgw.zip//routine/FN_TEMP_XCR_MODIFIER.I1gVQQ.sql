create FUNCTION        "FN_TEMP_XCR_MODIFIER" ( as_age_cls in char ) return char is 
    age_nfactor number; 
begin 
    select age_nfactor
    into age_nfactor 
    from temp_jic_xcr_age_nfactor
    where age_cls = as_age_cls; 
 
return age_nfactor; 
 
exception 
when others then 
    return '-1'; 
end;
/

