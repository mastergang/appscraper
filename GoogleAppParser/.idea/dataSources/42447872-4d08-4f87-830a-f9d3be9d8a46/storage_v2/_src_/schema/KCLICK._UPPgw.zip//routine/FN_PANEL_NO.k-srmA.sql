create FUNCTION          "FN_PANEL_NO" ( as_code in char ) return char is 
    panel_no varchar(10):= NULL; 
begin 
    select panel_no 
    into panel_no 
    from tb_panel 
    where panelid = as_code; 
 
if panel_no is null then 
    panel_no := as_code; 
end if; 
 
return panel_no; 
 
exception 
when others then 
    return as_code; 
end;

/

