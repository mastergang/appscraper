create FUNCTION          "FN_SITE_NAME" ( al_site_id in number ) return char is 
    site_name varchar(40) := NULL; 
begin 
    select site_name 
    into site_name 
    from vi_site_info 
    where site_id = al_site_id; 
 
return site_name; 
 
end;

/

