create FUNCTION          "FN_WEEK_MODIFIER" ( as_weekcode in char ) return char is 
    modifier number; 
begin 
    select modifier 
    into modifier 
    from tb_week_modifier 
    where weekcode = as_weekcode; 
 
return modifier; 
 
exception 
when others then 
    return '-1'; 
end;

/

