create FUNCTION          "FN_DAY_MODIFIER" ( as_access_day in char ) return char is 
    modifier number; 
begin 
    SELECT modifier 
    into modifier 
    FROM tb_day_modifier 
    WHERE access_day = as_access_day; 
 
return modifier; 
 
exception 
when others then 
    return '-1'; 
end;

/

