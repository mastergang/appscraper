create FUNCTION          "FN_SHOPPING_NAME" ( as_code in char ) return char is 
    category_name varchar2(100) := NULL; 
begin 
    select max(category_name) 
    into category_name 
    from tb_shop_category1 
    where category_code = as_code 
    order by ef_time desc; 
 
if category_name is null then 
    category_name := as_code; 
end if; 
 
return category_name; 
 
exception 
when others then 
    return as_code; 
end;

/

