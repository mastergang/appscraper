create FUNCTION          "FN_RETURN_PANEL_MEMO" ( panelid IN CHAR ) return char is 
    content varchar2(500):= NULL; 
begin 
    select content 
    into content 
    from
    (
        select content
        from    tb_panel_consult
        where   panel_id = panelid
        order by proc_date desc
    )
    where rownum = 1;

if content is null then 
    content := '무'; 
end if; 
 
return content; 
 
exception 
    when others then 
    return '무'; 
end;

/

