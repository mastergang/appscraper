create FUNCTION          "FN_SMART_MONTH_COUNT" ( as_monthcode in char ) return char is  
    total_nfactor number;  
begin  
    select panel_cnt  
    into total_nfactor  
    from tb_smart_month_netizen_cnt  
    where monthcode = as_monthcode;  
  
return total_nfactor;  
  
exception  
when others then  
    return '-1';  
end;

/

