create view VI_TEMP_CALCULATION_COMPAR2 as
SELECT a.device_cd,
       a.location,
       a.atelecom,
       a.itelecom,
       a.AISA_ANDROID,
       a.AISA_IOS,
       a.AISA_SEX_CLS,
       a.AISA_AGE_CLS,
       a.air_android,
       a.air_ios,
       a.air_region_cd,
       a.PASA_ANDROID,
       a.PASA_PC,
       a.PASA_SEX_CLS,
       a.PASA_AGE_CLS,
       a.PAR_android,
       a.PAR_PC,
       a.PAR_region_cd,
       a.PISA_pc,
       a.PISA_IOS,
       a.PISA_SEX_CLS,
       a.PISA_AGE_CLS,
       a.pir_pc,
       a.pir_ios,
       a.pir_region_cd,
       a.netizen_cnt,
       b.weight,
       round(b.weight) round_weight
FROM   (SELECT device_cd, null location, null atelecom, null itelecom, AISA_ANDROID, AISA_IOS, AISA_SEX_CLS, AISA_AGE_CLS, air_android, air_ios, air_region_cd, PASA_PC, PASA_ANDROID, PASA_SEX_CLS, PASA_AGE_CLS, PAR_pc, PAR_android, PAR_region_cd, PISA_PC, PISA_IOS, PISA_SEX_CLS, PISA_AGE_CLS, PIR_pc, PIR_ios, PIR_region_cd, sum(netizen_cnt) netizen_cnt
        FROM   (SELECT DEVICE_CD, decode(device_cd, '10', '10', '20', '20', '30', '10', '40', '20', '50', '20', '60', '10', '70', '10', '80', '50') AISA_ANDROID, decode(device_cd, '10', '20', '20', '20', '30', '20', '40', '10', '50', '10', '60', '10', '70', '10', '80', '50') AISA_IOS, decode(device_cd, '20', '99', sex_cls) AISA_SEX_CLS, DECODE(device_cd, '20', '99', AGE_CLS) AISA_AGE_CLS, decode(device_cd, '10', '10', '20', '20', '30', '10', '40', '20', '50', '20', '60', '10', '70', '10') air_android, decode(device_cd, '10', '20', '20', '20', '30', '20', '40', '10', '50', '10', '60', '10', '70', '10') air_ios, DECODE(device_cd, '20', '99', REGION_CD) air_region_cd, decode(device_cd, '10', '10', '20', '10', '30', '20', '40', '20', '50', '10', '60', '20', '70', '10', '80', '60') PASA_PC, decode(device_cd, '10', '10', '20', '20', '30', '10', '40', '20', '50', '20', '60', '10', '70', '10', '80', '60') PASA_ANDROID, DECODE(device_Cd, '40', '99', SEX_CLS) PASA_SEX_CLS, DECODE(device_cd, '40', '99', AGE_CLS) PASA_AGE_CLS, decode(device_cd, '10', '10', '20', '10', '30', '20', '40', '20', '50', '10', '60', '20', '70', '10', '80', '70') PAR_pc, decode(device_cd, '10', '10', '20', '20', '30', '10', '40', '20', '50', '20', '60', '10', '70', '10', '80', '70') PAR_android, DECODE(device_Cd, '40', '99', REGION_CD) PAR_region_cd, decode(device_cd, '10', '10', '20', '10', '30', '20', '40', '20', '50', '10', '60', '20', '70', '10', '80', '80') PISA_PC, decode(device_cd, '10', '20', '20', '20', '30', '20', '40', '10', '50', '10', '60', '10', '70', '10', '80', '80') PISA_IOS, DECODE(device_cd, '30', '99', SEX_CLS) PISA_SEX_CLS, DECODE(device_cd, '30', '99', AGE_CLS) PISA_AGE_CLS, decode(device_cd, '10', '10', '20', '10', '30', '20', '40', '20', '50', '10', '60', '20', '70', '10', '80', '90') PIR_PC, decode(device_cd, '10', '20', '20', '20', '30', '20', '40', '10', '50', '10', '60', '10', '70', '10', '80', '90') PIR_ios, DECODE(device_cd, '30', '99', REGION_CD) PIR_region_cd, netizen_cnt
                FROM   TEMP_KWHSIN_ALL_NETIZEN
                WHERE  EXP_TIME > SYSDATE )
        group by grouping sets(device_Cd, (AISA_ANDROID,
                               AISA_IOS,
                               AISA_SEX_CLS,
                               AISA_AGE_CLS), (air_android,
                               air_ios,
                               air_region_cd), (PASA_PC,
                               PASA_ANDROID,
                               PASA_SEX_CLS,
                               PASA_AGE_CLS), (PAR_pc,
                               PAR_android,
                               PAR_region_cd), (PISA_PC,
                               PISA_IOS,
                               PISA_SEX_CLS,
                               PISA_AGE_CLS), (PIR_pc,
                               PIR_ios,
                               PIR_region_cd))
        union all
select null device_cd, location , null atelecom, null itelecom, null aisa_android, null aisa_ios, null aisa_Sex, null aisa_age, null air_android, null air_ios, null air_region, null pasa_pc, null pasa_android, null pasa_Sex, null pasa_age, null par_pc, null par_android, null par_region, null pisa_pc, null pisa_ios, null pisa_Sex, null pisa_age, null pir_pc, null pir_ios, null pir_region, netizen_cnt
        from   temp_kwshin_loc_netizen
        WHERE  EXP_TIME > SYSDATE
        union all
select null device_cd, null location , telecom_cd atelecom, null itelecom, null aisa_android, null aisa_ios, null aisa_Sex, null aisa_age, null air_android, null air_ios, null air_region, null pasa_pc, null pasa_android, null pasa_Sex, null pasa_age, null par_pc, null par_android, null par_region, null pisa_pc, null pisa_ios, null pisa_Sex, null pisa_age, null pir_pc, null pir_ios, null pir_region, netizen_cnt
        from   temp_kwshin_telecom_netizen
        WHERE  EXP_TIME > SYSDATE
        union all
select null device_cd, null location , null atelecom, telecom_Cd itelecom, null aisa_android, null aisa_ios, null aisa_Sex, null aisa_age, null air_android, null air_ios, null air_region, null pasa_pc, null pasa_android, null pasa_Sex, null pasa_age, null par_pc, null par_android, null par_region, null pisa_pc, null pisa_ios, null pisa_Sex, null pisa_age, null pir_pc, null pir_ios, null pir_region, netizen_cnt
        from   temp_kwshin_IOS_tnetizen
        WHERE  EXP_TIME > SYSDATE ) a,
       (SELECT device_cd,
               location,
               decode(device_cd, '20', '50', '40', '50', '50', '50', telecom_cd) atelecom,
               decode(device_cd, '10', '50', '20', '50', '30', '50', telecom_cd) itelecom,
               decode(device_cd, '10', '10', '20', '20', '30', '10', '40', '20', '50', '20', '60', '10', '70', '10', '80', '50') aisa_android,
               decode(device_cd, '10', '20', '20', '20', '30', '20', '40', '10', '50', '10', '60', '10', '70', '10', '80', '50') aisa_ios,
               DECODE(device_cd, '20', '99', SEX_CLS) AISA_SEX_CLS,
               DECODE(device_cd, '20', '99', AGE_CLS) AISA_AGE_CLS,
               decode(device_cd, '10', '10', '20', '20', '30', '10', '40', '20', '50', '20', '60', '10', '70', '10') air_android,
               decode(device_cd, '10', '20', '20', '20', '30', '20', '40', '10', '50', '10', '60', '10', '70', '10') air_ios,
               DECODE(device_cd, '20', '99', REGION_CD) air_region_cd,
               decode(device_cd, '10', '10', '20', '10', '30', '20', '40', '20', '50', '10', '60', '20', '70', '10', '80', '60') PASA_PC,
               decode(device_cd, '10', '10', '20', '20', '30', '10', '40', '20', '50', '20', '60', '10', '70', '10', '80', '60') PASA_ANDROID,
               DECODE(device_cd, '40', '99', SEX_CLS) PASA_SEX_CLS,
               DECODE(device_cd, '40', '99', AGE_CLS) PASA_AGE_CLS,
               decode(device_cd, '10', '10', '20', '10', '30', '20', '40', '20', '50', '10', '60', '20', '70', '10', '80', '70') PAR_pc,
               decode(device_cd, '10', '10', '20', '20', '30', '10', '40', '20', '50', '20', '60', '10', '70', '10', '80', '70') PAR_android,
               DECODE(device_cd, '40', '99', REGION_CD) PAR_region_cd,
               decode(device_cd, '10', '10', '20', '10', '30', '20', '40', '20', '50', '10', '60', '20', '70', '10', '80', '80') PISA_PC,
               decode(device_cd, '10', '20', '20', '20', '30', '20', '40', '10', '50', '10', '60', '10', '70', '10', '80', '80') PISA_IOS,
               DECODE(device_cd, '30', '99', SEX_CLS) PISA_SEX_CLS,
               DECODE(device_cd, '30', '99', AGE_CLS) PISA_AGE_CLS,
               decode(device_cd, '10', '10', '20', '10', '30', '20', '40', '20', '50', '10', '60', '20', '70', '10', '80', '90') PIR_PC,
               decode(device_cd, '10', '20', '20', '20', '30', '20', '40', '10', '50', '10', '60', '10', '70', '10', '80', '90') PIR_ios,
               DECODE(device_cd, '30', '99', REGION_CD) PIR_region_cd,
               sum(n_weight) weight
        FROM   tb_temp_calculation_weight2
        GROUP BY GROUPING SETS(DEVICE_CD, LOCATION, (decode(device_cd, '20', '50', '40', '50', '50', '50', telecom_cd)), (decode(device_cd, '10', '50', '20', '50', '30', '50', telecom_cd)), ( decode(device_cd, '10', '10', '20', '20', '30', '10', '40', '20', '50', '20', '60', '10', '70', '10', '80', '50') ,
                               decode(device_cd, '10', '20', '20', '20', '30', '20', '40', '10', '50', '10', '60', '10', '70', '10', '80', '50') ,
                               DECODE(device_cd, '20', '99', SEX_CLS),
                               DECODE(device_cd, '20', '99', AGE_CLS) ), ( decode(device_cd, '10', '10', '20', '20', '30', '10', '40', '20', '50', '20', '60', '10', '70', '10') ,
                               decode(device_cd, '10', '20', '20', '20', '30', '20', '40', '10', '50', '10', '60', '10', '70', '10') ,
                               DECODE(device_cd, '20', '99', REGION_CD) ) , ( decode(device_cd, '10', '10', '20', '10', '30', '20', '40', '20', '50', '10', '60', '20', '70', '10', '80', '60'),
                               decode(device_cd, '10', '10', '20', '20', '30', '10', '40', '20', '50', '20', '60', '10', '70', '10', '80', '60'),
                               DECODE(device_cd, '40', '99', SEX_CLS),
                               DECODE(device_cd, '40', '99', AGE_CLS)), ( decode(device_cd, '10', '10', '20', '10', '30', '20', '40', '20', '50', '10', '60', '20', '70', '10', '80', '70'),
                               decode(device_cd, '10', '10', '20', '20', '30', '10', '40', '20', '50', '20', '60', '10', '70', '10', '80', '70'),
                               DECODE(device_cd, '40', '99', REGION_CD) ), ( decode(device_cd, '10', '10', '20', '10', '30', '20', '40', '20', '50', '10', '60', '20', '70', '10', '80', '80'),
                               decode(device_cd, '10', '20', '20', '20', '30', '20', '40', '10', '50', '10', '60', '10', '70', '10', '80', '80'),
                               DECODE(device_cd, '30', '99', SEX_CLS),
                               DECODE(device_cd, '30', '99', AGE_CLS) ), ( decode(device_cd, '10', '10', '20', '10', '30', '20', '40', '20', '50', '10', '60', '20', '70', '10', '80', '90') ,
                               decode(device_cd, '10', '20', '20', '20', '30', '20', '40', '10', '50', '10', '60', '10', '70', '10', '80', '90') ,
                               DECODE(device_cd, '30', '99', REGION_CD) ) ) ) b
WHERE  nvl(a.device_cd, '0')=nvl(b.device_cd, '0')
and    nvl(a.location, '0')=nvl(b.location, '0')
and    nvl(a.atelecom, '0')=nvl(b.atelecom, '0')
and    nvl(a.itelecom, '0')=nvl(b.itelecom, '0')
and    nvl(a.aisa_android, '0')=nvl(b.aisa_android, '0')
and    nvl(a.aisa_ios, '0')=nvl(b.aisa_ios, '0')
and    nvl(a.aisa_sex_cls, '0')=nvl(b.aisa_sex_cls, '0')
and    nvl(a.aisa_age_cls, '0')=nvl(b.aisa_age_cls, '0')
and    nvl(a.air_android, '0')=nvl(b.air_android, '0')
and    nvl(a.air_ios, '0')=nvl(b.air_ios, '0')
and    nvl(a.air_region_cd, '0')=nvl(b.air_region_cd, '0')
and    nvl(a.pasa_android, '0')=nvl(b.pasa_android, '0')
and    nvl(a.pasa_pc, '0')=nvl(b.pasa_pc, '0')
and    nvl(a.pasa_sex_cls, '0')=nvl(b.pasa_sex_cls, '0')
and    nvl(a.pasa_age_cls, '0')=nvl(b.pasa_age_cls, '0')
and    nvl(a.par_android, '0')=nvl(b.par_android, '0')
and    nvl(a.par_pc, '0')=nvl(b.par_pc, '0')
and    nvl(a.par_region_cd, '0')=nvl(b.par_region_cd, '0')
and    nvl(a.pisa_pc, '0')=nvl(b.pisa_pc, '0')
and    nvl(a.pisa_ios, '0')=nvl(b.pisa_ios, '0')
and    nvl(a.pisa_sex_cls, '0')=nvl(b.pisa_sex_cls, '0')
and    nvl(a.pisa_age_cls, '0')=nvl(b.pisa_age_cls, '0')
and    nvl(a.pir_pc, '0')=nvl(b.pir_pc, '0')
and    nvl(a.pir_ios, '0')=nvl(b.pir_ios, '0')
and    nvl(a.pir_region_cd, '0')=nvl(b.pir_region_cd, '0')
and    round(netizen_cnt)=round(weight)
/

