create FUNCTION        "FN_IOS_DAY_NFACTOR" ( as_access_day in char ) return char is  
    nfactor number;  
begin  
    if as_access_day < 20120301 then nfactor:=-1;
    else 
        select NETIZEN_CNT into nfactor  
        from tb_IOS_day_netizen_cnt
        where access_day = as_access_day;
    end if;
return nfactor;
  
exception  
when others then  
    return '-1';  
end;
/

