create FUNCTION          "FN_SMART_PACKAGE_NAME" ( al_smart_id in number ) return char is    
    package_name varchar(100) := NULL;    
begin    
    select package_name    
    into package_name    
    from tb_smart_app_info    
    where smart_id = al_smart_id
    and   exp_time > sysdate;    
    
return package_name;    
    
end;

/

