create view VI_WEEK_MODIFIER as
select weekcode, fn_week_netizen(weekcode)/sum(kc_n_factor) modifier
from tb_panel_seg
group by weekcode

/

