create FUNCTION        "FN_IOS_DAY_COUNT" ( as_access_day in char ) return char is  
    cnt number;  
begin  
    if as_access_day < 20120301 then cnt:=-1;
    else 
        select panel_cnt into cnt  
        from tb_IOS_day_netizen_cnt
        where access_day = as_access_day;
    end if;
return cnt;
  
exception  
when others then  
    return '-1';  
end;
/

