create FUNCTION        "FN_DECODE" ( qstring in varchar2 ) return varchar2 is 
    decode_str varchar(1000); 
    j number; 
begin 
    j := 0; 
    for i in 1..length(qstring) loop 
        if j > 0 then 
        j:=j-1; 
        else 
            if substr(qstring,i,1) = '+' then 
            decode_str := decode_str || ' '; 
            elsif substr(qstring,i,1) = '%' then 
            decode_str := decode_str || chr(to_dec(replace(substr(qstring,i+1,5),'%'))); 
            j := 5; 
            else 
            decode_str := decode_str || substr(qstring,i,1); 
            end if; 
        end if; 
    end loop; 
 
return decode_str; 
 
end;
/

