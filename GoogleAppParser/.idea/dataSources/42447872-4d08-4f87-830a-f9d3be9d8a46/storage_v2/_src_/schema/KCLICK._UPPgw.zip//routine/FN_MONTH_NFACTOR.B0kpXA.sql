create FUNCTION          "FN_MONTH_NFACTOR" ( as_monthcode in char ) return char is 
    total_nfactor number; 
begin 
    select total_nfactor 
    into total_nfactor 
    from tb_month_modifier 
    where monthcode = as_monthcode; 
 
return total_nfactor; 
 
exception 
when others then 
    return '-1'; 
end;

/

