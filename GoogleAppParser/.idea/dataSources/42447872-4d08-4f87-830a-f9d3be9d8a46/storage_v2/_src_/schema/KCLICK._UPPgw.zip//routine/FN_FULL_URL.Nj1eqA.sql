create FUNCTION          "FN_FULL_URL" ( as_domain in char, as_page in char, as_parameter in char default null) return char is 
    path_url varchar2(2000):= NULL;
begin 
    select case when as_parameter is not null then 
                as_domain||decode(as_page||as_parameter,null,null,'/'||as_page)||decode(as_parameter,null,null,'?'||as_parameter)
           else as_domain||decode(as_page,null,null,'/'||as_page) end
    into path_url 
    from dual; 
 
return path_url; 
 
exception 
when others then 
    return '-1'; 
end;

/

