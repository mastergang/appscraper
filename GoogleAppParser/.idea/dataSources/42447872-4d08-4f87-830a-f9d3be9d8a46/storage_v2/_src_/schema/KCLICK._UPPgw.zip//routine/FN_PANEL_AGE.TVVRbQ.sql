create FUNCTION          "FN_PANEL_AGE" ( JUBUN IN VARCHAR2 ) return number is      
  V_AGE NUMBER; 
 
BEGIN 
 
    IF SUBSTR(JUBUN, 7,1) IN(1,2)   
 
      THEN V_AGE := EXTRACT(YEAR FROM SYSDATE) - (SUBSTR(JUBUN,1,2)+1900); 
 
    ELSE V_AGE := EXTRACT(YEAR FROM SYSDATE) - (SUBSTR(JUBUN,1,2)+2000); 
 
    END IF; 
 
    V_AGE := V_AGE ; 
 
    RETURN V_AGE; 
 
END;

/

