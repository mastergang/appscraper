create FUNCTION          "FN_SMART_ID_NAME" ( al_package_name in varchar2 ) return char is
    app_name varchar2(100) := NULL; 
begin
    select app_name
    into app_name
    from tb_smart_app_info
    where package_name = al_package_name
    and   ef_time < sysdate
    and   exp_time > sysdate;
    
if app_name is null then 
app_name := al_package_name; 
end if; 
    
return app_name;

end;

/

