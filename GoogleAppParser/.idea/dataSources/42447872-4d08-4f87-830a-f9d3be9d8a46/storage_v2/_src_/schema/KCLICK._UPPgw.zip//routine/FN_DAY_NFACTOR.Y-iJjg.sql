create FUNCTION          "FN_DAY_NFACTOR" ( as_access_day in char ) return char is 
    total_nfactor number; 
begin 
    select total_nfactor 
    into total_nfactor 
    from tb_day_modifier 
    where access_day = as_access_day; 
 
return total_nfactor; 
 
exception 
when others then 
    return '-1'; 
end;

/

