create FUNCTION        FN_app_type ( as_code in char ) return char is 
    app_type varchar2(40):= NULL; 
begin 
    select code_name 
    into app_type
    from tb_codebook 
    where meta_code = 'APP_TYPE' 
    and code = as_code; 
if app_type is null then 
    app_type := as_code; 
end if; 
 
return app_type; 
 
exception 
    when others then 
    return as_code; 
end;
/

