create FUNCTION        "FN_GET_ISP" ( ip in varchar) return char is 
    ip_number number ; 
    my_isp varchar(20); 
begin 
    select fn_ip2long(ip) 
    into ip_number 
    from dual; 
    select isp 
    into my_isp 
    from tb_isp_info 
    where ip_number >= start_num 
    and ip_number <= end_num; 
 
return my_isp; 
 
end;
/

