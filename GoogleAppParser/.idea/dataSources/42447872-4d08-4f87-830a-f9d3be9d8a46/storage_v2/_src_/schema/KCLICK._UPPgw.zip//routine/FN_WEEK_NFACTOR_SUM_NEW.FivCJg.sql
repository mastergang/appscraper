create FUNCTION "FN_WEEK_NFACTOR_SUM_NEW" ( as_weekcode in char ) return char is  
    total_nfactor number;  
begin  
    select sum(kc_n_factor)  
    into total_nfactor  
    from tb_panel_seg  
    where weekcode = as_weekcode 
    and panel_id in ( select panel_id from tb_loc_panel_seg where  weekcode = as_weekcode and loc_cd != 4 group by panel_id); 
     
return total_nfactor;  
  
exception  
when others then  
    return '-1';  
end;
/

