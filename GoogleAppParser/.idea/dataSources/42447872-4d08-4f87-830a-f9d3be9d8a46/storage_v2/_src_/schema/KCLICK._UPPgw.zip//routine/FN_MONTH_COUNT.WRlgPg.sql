create FUNCTION          "FN_MONTH_COUNT" ( as_monthcode in char ) return char is 
    total_nfactor number; 
begin 
    select count(*) 
    into total_nfactor 
    from tb_month_panel_seg 
    where monthcode = as_monthcode; 
 
return total_nfactor; 
 
exception 
when others then 
    return '-1'; 
end;

/

