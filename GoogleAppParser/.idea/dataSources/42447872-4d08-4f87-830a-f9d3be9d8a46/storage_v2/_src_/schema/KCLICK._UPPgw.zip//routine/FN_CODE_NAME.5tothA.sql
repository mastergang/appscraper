create FUNCTION          "FN_CODE_NAME" ( as_meta_code in char, as_code in char) return char is 
    t_code_name varchar2(50); 
begin 
    select code_name 
    into t_code_name 
    from tb_codebook 
    where meta_code = as_meta_code 
    and code = as_code; 
 
return t_code_name; 
 
end;

/

