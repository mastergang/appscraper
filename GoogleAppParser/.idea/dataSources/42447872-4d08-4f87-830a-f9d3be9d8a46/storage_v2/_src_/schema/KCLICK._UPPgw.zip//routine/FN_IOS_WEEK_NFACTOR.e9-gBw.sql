create FUNCTION        "FN_IOS_WEEK_NFACTOR" ( as_weekcode in char ) return char is  
    nfactor number;  
begin  
    if as_weekcode < 201139 then nfactor:=-1;
    else 
        select NETIZEN_CNT into nfactor  
        from tb_ios_week_netizen_cnt
        where weekcode = as_weekcode;
    end if;
return nfactor;
  
exception  
when others then  
    return '-1';  
end;
/

