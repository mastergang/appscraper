create FUNCTION          "FN_SMART_PFACTOR" ( as_sex_cls in char, as_age_cls in char, as_accessday in char ) return char is 
    weight number; 
begin 
    select P_WEIGHT  
    into weight 
    from tb_smart_panel_weight  
    where sex_cls = as_sex_cls
    and   age_cls = as_age_cls
    and   exp_time >= to_date(as_accessday,'yyyymmdd')
    and   ef_time  <= to_date(as_accessday,'yyyymmdd'); 
 
return weight; 
 
exception 
when others then 
    return '-1'; 
end;

/

