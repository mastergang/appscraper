create FUNCTION          "FN_SMART_ENG_APP_CATEGORY" ( AL_APP_CATEGORY_CD in varchar ) return char is    
    ENG_APP_CATEGORY_NAME varchar(100) := NULL;    
begin    
    select ENG_APP_CATEGORY_NAME    
    into ENG_APP_CATEGORY_NAME    
    from (  
        select APP_CATEGORY_CD1 CATE_CD, ENG_APP_CATEGORY_NAME from TB_SMART_APP_CATEGORY_CD1  
        union all  
        select APP_CATEGORY_CD2 CATE_CD, ENG_APP_CATEGORY_NAME from TB_SMART_APP_CATEGORY_CD2  
    )  
    where CATE_CD = AL_APP_CATEGORY_CD;    
    
return ENG_APP_CATEGORY_NAME;    
    
end;

/

