create FUNCTION          "FN_TOTAL_NFACTOR" ( as_monthcode in char ) return char is 
    total_nfactor number; 
begin 
    select sum(NETIZEN_CNT) into total_nfactor 
    from   tb_nielsen_netizen
    where  exp_time >= to_date(fn_month_lastday(as_monthcode),'yyyymmdd')+1-interval '1' second
    and    ef_time  < to_date(fn_month_lastday(as_monthcode),'yyyymmdd')+1-interval '1' second;
 
return total_nfactor; 
 
exception 
when others then 
    return '-1'; 
end;

/

