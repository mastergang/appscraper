create FUNCTION          "FN_RETURN_PAGE" (full_url IN CHAR) RETURN CHAR IS  
    has_protocol BOOLEAN := full_url LIKE 'http://%' OR full_url LIKE 'https://%'; 
    start_pos NUMBER := 1; 
    url VARCHAR2(2000); 
    len NUMBER := 5; 
    end_pos NUMBER; 
BEGIN 
 
IF has_protocol THEN 
    start_pos := 9; 
END IF; 
 
start_pos := INSTR(full_url, '/', start_pos); 
 
IF start_pos < 1 THEN 
    IF has_protocol THEN 
        RETURN ''; 
    END IF; 
    url := full_url; 
ELSE 
    url := SUBSTR(full_url, start_pos + 1, LENGTH(full_url)); 
END IF; 
 
IF url LIKE '%?%' THEN 
    RETURN SUBSTR(url, 1, INSTR(url, '?') - 1); 
ELSIF url LIKE '%#%' THEN 
    RETURN SUBSTR(url, 1, INSTR(url, '#') - 1); 
END IF; 
 
RETURN url; 
 
EXCEPTION 
WHEN OTHERS THEN 
    RETURN ''; 
END;

/

