create view VI_SECTION_CODE as
select  to_number(code) section_id,
        code_name section_name,
        to_number(nvl(code_etc, code)) psection_id,
        decode(code_etc, NULL, 'N', 'Y') isupper_code
from  tb_codebook
where meta_code ='SECTION'

/

