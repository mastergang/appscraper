create FUNCTION          "FN_INCOME_NAME" ( as_code in char ) return char is 
    inc_name varchar2(50):= NULL; 
begin 
    select code_name 
    into inc_name 
    from tb_codebook 
    where meta_code = 'INCOME' 
    and code = as_code; 
 
if inc_name is null then 
    inc_name := as_code; 
end if; 
 
return inc_name; 
 
exception 
when others then 
    return '기타'; 
end;

/

