create FUNCTION          "TO_HEX" ( p_dec in number ) return varchar2 is 
begin 
    return to_base( p_dec, 16 ); 
end to_hex;

/

