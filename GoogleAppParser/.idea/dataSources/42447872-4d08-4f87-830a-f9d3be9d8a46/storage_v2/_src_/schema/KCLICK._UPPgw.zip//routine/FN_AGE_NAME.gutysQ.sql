create FUNCTION          "FN_AGE_NAME" ( as_code in char ) return char is 
    age_name varchar2(20):= NULL; 
begin 
    select code_name 
    into age_name 
    from tb_codebook 
    where meta_code = 'KC_AGE_CLS' 
    and code = as_code; 
if age_name is null then 
    age_name := as_code; 
end if; 
 
return age_name; 
 
exception 
    when others then 
    return as_code; 
end;

/

