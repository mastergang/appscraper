create procedure Mobile_pre_duration
( p_monthcode IN varchar2 )
IS

BEGIN

     update TB_SMART_DNA_ITRACK set DURATION_M = DURATION where access_Day between p_monthcode||'01' and p_monthcode||'31';

     --1. duration > copyline_duration 이고 다른 copyline_id 가 있는 경우 체크하여 update
     update /*+ BYPASS_UJVC */
     (
          --현재 duration보다 큰 copyline_id중 가장 작은 copyline_duration을 선택
          select a.*, b.COPYLINE_ID copy_id
          from
          (
               select rowid row_id, a.*
               from TB_SMART_DNA_ITRACK a
               where access_Day between p_monthcode||'01' and p_monthcode||'31'
          )a,
          (
                --다른 copyline_id중 현재 duration보다 큰 것만 select
               select access_day, panel_id, row_id, a.copyline, COPYLINE_ID, duration, copy_duration, rank() over(partition by row_id order by COPY_DURATION asc) rnk 
               from
               (
                    select ACCESS_DAY, rowid row_id, PANEL_ID, DURATION, substr(copyline_id,1,16) copyline
                    From TB_SMART_DNA_ITRACK 
                    where access_Day between p_monthcode||'01' and p_monthcode||'31'
                    and duration > 0
                    and to_number(substr(COPYLINE_ID,-3)) < duration
               )a,
               (
                    select COPYLINE_ID, substr(copyline_id,1,16) copyline, to_number(substr(COPYLINE_ID,-3)) copy_duration
                    From tb_tar_ref_digital@red2 
                    where monthcode = P_monthcode
                    group by COPYLINE_ID, substr(copyline_id,1,16), to_number(substr(COPYLINE_ID,-3))
               )b
               where a.copyline = b.copyline
               and COPY_DURATION > DURATION
               order by ROW_ID
          )b
          where a.row_id = b.row_id
          and rnk = 1
     )
     set COPYLINE_ID = copy_id;

     commit;


     -- 2. 그 외에 duration > copyline_duration 인 경우(다른 copyline의 duration이 없는경우) 에는 copyline의 duration으로 DURATION_M을 update 
     update  TB_SMART_DNA_ITRACK 
     set DURATION_M = to_number(substr(COPYLINE_ID,-3))
     where access_Day  between  p_monthcode||'01' and p_monthcode||'31'
     and duration > 0
     and to_number(substr(COPYLINE_ID,-3)) < duration;
     commit; 
     
END;
/

