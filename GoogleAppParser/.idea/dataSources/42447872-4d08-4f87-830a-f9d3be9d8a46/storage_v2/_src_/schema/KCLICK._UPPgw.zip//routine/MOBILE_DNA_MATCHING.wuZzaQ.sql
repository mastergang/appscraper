create procedure Mobile_dna_matching 
( p_monthcode IN varchar2 )
IS

BEGIN

     delete from tb_smart_dna_complete where access_Day  between p_monthcode||'01' and p_monthcode||'31';
     insert into tb_smart_dna_complete
     select ACCESS_DAY,PNEL_NO,NAME,DATA_ID,dates,
     to_char(dates,'HH24MISS') as STARTTIME, to_char(dates+numtodsinterval(DURATION, 'SECOND'),'HH24MISS') as ENDTIME,
     TIME_GAP,DURATION,
     ADVERTISER,BRAND,CATEGORY,BRAND_ID,SITE_CODE,
     CASE
          WHEN SITE_CODE in (89001,80007,80015,89002) THEN 'OK'--대상 package_name/ 현재는 youtube만 진행 중
          ELSE 'GG' END as VAL,'',sysdate,'','','', FILE_NAME, null, COPYLINE_id, panel_id, PACKAGE_NAME
     from (

         select ACCESS_DAY,pnel_no,decode(S_NAME,null,PACKAGE_NAME,S_NAME) as name, DATA_ID, REGISTER_DATE,
         to_date(to_char(REGISTER_DATE-numtodsinterval(nvl(DURATION,0), 'SECOND'),'YYYY/MM/DD HH24:MI:SS'),'YYYY/MM/DD HH24:MI:SS') as dates,
         TIME_GAP,DURATION,
         ADVERTISER,BRAND,CATEGORY,BRAND_ID,SITE_CODE, FILE_NAME, COPYLINE_id, panel_id, PACKAGE_NAME
         from
         (
             select a.ACCESS_DAY,a.panel_id,(select panel_no from tb_panel where panelid=a.PANEL_ID) as pnel_no,(select APP_NAME from tb_smart_app_info
             where PACKAGE_NAME=a.PACKAGE_NAME
             and EXP_TIME > sysdate) as S_NAME,a.PACKAGE_NAME,a.DATA_ID,REGISTER_DATE,TIME_GAP, DURATION_M DURATION,ADVERTISER,BRAND,CATEGORY,BRAND_ID,SITE_CODE, FILE_NAME, a.COPYLINE_id
             from TB_SMART_DNA_ITRACK a, TB_TAR_REF_DIGITAL@red2 b, tb_smart_month_panel_seg c
             where a.access_day between p_monthcode||'01' and p_monthcode||'31' 
             and a.data_id = b.data_id
             and a.panel_id=c.panel_id
             and c.monthcode =  p_monthcode
             and a.duration > 0
             and a.duration is not null
         )
     ) ;
     commit;

     --duration 합산 부분을 위한 임시 테이블 생성
     EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMP_TAR_SIMUL_NEW'; 
     insert into temp_tar_simul_new
     select rownum row_id, ACCESS_DAY,PANEL_NO, panel_id, REGISTER_DATE DATES, STARTTIME, ENDTIME,
             DURATION, ADVERTISER,BRAND,CATEOGORY,BRAND_ID, NAME, PACKAGE_NAME, MEDIUM SITE_CODE, FILE_NAME, COPYLINE,null,null,null,null
     from tb_smart_dna_complete
     where access_day between p_monthcode||'01' and p_monthcode||'31';
     commit;
     
END;
/

