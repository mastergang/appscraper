create FUNCTION        "FN_DAY_MODIFIER_SUM_NEW" ( as_access_day in char ) return char is
    total_nfactor number;
begin
    SELECT var2/var1
    into total_nfactor
    FROM
    (
        SELECT sum(kc_n_factor) var1
        FROM tb_day_total_panel_seg
        WHERE access_day = as_access_day
    ),
    (
        SELECT sum(netizen_cnt) var2
        FROM tb_nielsen_netizen
        WHERE exp_time > to_date(as_access_day,'YYYYMMDD') 
        AND ef_time < to_date(as_access_day,'YYYYMMDD') +1
    );

return total_nfactor;

exception
when others then
    return '-1';
end;
/

