create FUNCTION        "FN_TCR_MONTH_MODIFIER" ( as_monthcode in char ) return char is  
    modifier number;  
begin  
    select modifier  
    into modifier  
    from tb_tcr_month_modifier  
    where monthcode = as_monthcode;  
  
return modifier;  
  
exception  
when others then  
    return '-1';  
end;
/

