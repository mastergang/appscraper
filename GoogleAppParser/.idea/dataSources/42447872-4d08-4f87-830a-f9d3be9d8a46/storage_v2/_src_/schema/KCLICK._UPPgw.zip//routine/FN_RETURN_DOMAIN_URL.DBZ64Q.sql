create FUNCTION          "FN_RETURN_DOMAIN_URL" (full_url IN CHAR) RETURN CHAR IS  
    end_pos NUMBER; 
BEGIN 
    IF full_url LIKE 'http://%' OR full_url LIKE 'https://%' THEN 
        end_pos := INSTR(full_url, '/', 9); 
        IF end_pos < 1 THEN 
            end_pos := INSTR(full_url, '?', 9); 
            IF end_pos < 1 THEN 
                end_pos := INSTR(full_url, '#', 9); 
                IF end_pos < 1 THEN 
                    end_pos := LENGTH(full_url) + 1; 
                END IF; 
            END IF; 
        END IF; 
 
RETURN SUBSTR(full_url, 1, end_pos - 1); 
 
    ELSE RETURN ''; 
    END IF; 
 
EXCEPTION 
WHEN OTHERS THEN 
    RETURN ''; 
END;

/

