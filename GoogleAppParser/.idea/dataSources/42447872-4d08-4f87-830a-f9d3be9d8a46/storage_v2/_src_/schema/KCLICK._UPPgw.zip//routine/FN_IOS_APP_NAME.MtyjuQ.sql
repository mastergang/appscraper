create FUNCTION        "FN_IOS_APP_NAME" ( al_ios_id in number ) return char is 
    app_name varchar(100) := NULL; 
begin 
    select app_name 
    into app_name 
    from tb_mobile_app_info 
    where ios_id = al_ios_id
    and   ef_time < sysdate
    and   exp_time > sysdate
    and   ios_id is not null; 
 
return app_name; 
 
end;
/

