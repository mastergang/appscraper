create FUNCTION        FN_TOTAL_week_NFACTOR ( weekcode in char ) return char is
    modifier number;
    total_netizen number;
    total_nfactor number;
begin

if(weekcode<'201143') then total_netizen := -1;
    elsif((weekcode>='201143') and (weekcode<='201152')) then total_netizen := 32279315;
    elsif((weekcode>='201201') and (weekcode<='201213')) then total_netizen := 32005855;
    elsif((weekcode>='201214') and (weekcode<='201226')) then total_netizen := 32165472;
    elsif((weekcode>='201227') and (weekcode<='201239')) then total_netizen := 34610507;
    elsif((weekcode>='201240') and (weekcode<='201252')) then total_netizen := 34643388;
    elsif((weekcode>='201253') and (weekcode<='201312')) then total_netizen := 34917664;
    elsif((weekcode>='201313') and (weekcode<='201325')) then total_netizen := 34807589;
    elsif((weekcode>='201326') and (weekcode<='201338')) then total_netizen := 35321515;
    elsif((weekcode>='201339') and (weekcode<='201351')) then total_netizen := 35553134;
    elsif((weekcode>='201352') and (weekcode<='201412')) then total_netizen := 36085110;
    elsif((weekcode>='201413') and (weekcode<='201425')) then total_netizen := 36499569;
    elsif((weekcode>='201426') and (weekcode<='201438')) then total_netizen := 36674642;
    elsif((weekcode>='201439') and (weekcode<='201451')) then total_netizen := 37021629;
    elsif((weekcode>='201452') and (weekcode<='201512')) then total_netizen := 37262220;
    elsif((weekcode>='201513') and (weekcode<='201525')) then total_netizen := 37414957;
    elsif((weekcode>='201526') and (weekcode<='201538')) then total_netizen := 37593796;
    elsif((weekcode>='201539') and (weekcode<='201551')) then total_netizen := 37768273;
    elsif((weekcode>='201552') and (weekcode<='201612')) then total_netizen := 37849124;
    elsif((weekcode>='201613') and (weekcode<='201625')) then total_netizen := 38005964;
    elsif((weekcode>='201626') and (weekcode<='201638')) then total_netizen := 38155667;
    elsif((weekcode>='201639') and (weekcode<='201652')) then total_netizen := 38169043;
    elsif((weekcode>='201701') and (weekcode<='201713')) then total_netizen := 38279403;
    elsif((weekcode>='201714') and (weekcode<='201726')) then total_netizen := 38352550;
    elsif((weekcode>='201727') and (weekcode<='201739')) then total_netizen := 38408829;
    elsif((weekcode>='201740') and (weekcode<='201752')) then total_netizen := 38584526;
    elsif((weekcode>='201801') and (weekcode<='201813')) then total_netizen := 38680119;
    elsif((weekcode>='201814') and (weekcode<='201826')) then total_netizen := 38900619;
    elsif((weekcode>='201827') and (weekcode<='201839')) then total_netizen := 39058834;
    elsif((weekcode>='201840') and (weekcode<='201852')) then total_netizen := 38914982;
    elsif((weekcode>='201853') and (weekcode<='201912')) then total_netizen := 39509412;
    elsif((weekcode>='201913') and (weekcode<='201925')) then total_netizen := 40591701;
    else   total_netizen := 40755353; 
end if;

return total_netizen;

exception
when others then
    return '-1';
end;
/

