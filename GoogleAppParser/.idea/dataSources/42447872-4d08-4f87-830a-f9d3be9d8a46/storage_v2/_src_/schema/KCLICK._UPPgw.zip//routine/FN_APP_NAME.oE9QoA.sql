create FUNCTION          "FN_APP_NAME" ( al_app_id in number ) return char 
is 
my_app_name varchar(70); 
begin 
    select app_name into my_app_name from tb_app_info 
    where app_id = al_app_id 
    and exp_time >= sysdate; 
 
return my_app_name; 
 
end;

/

