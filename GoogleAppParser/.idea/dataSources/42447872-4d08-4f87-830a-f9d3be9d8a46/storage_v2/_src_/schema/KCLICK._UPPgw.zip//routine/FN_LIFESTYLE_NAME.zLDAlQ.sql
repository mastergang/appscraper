create FUNCTION          "FN_LIFESTYLE_NAME" ( as_code in char ) return char is 
    life_name varchar2(50):= NULL; 
begin 
    select code_name 
    into life_name 
    from tb_codebook 
    where meta_code = 'LIFESTYLE' 
    and code = as_code; 
 
if life_name is null then 
    life_name := as_code; 
end if; 
 
return life_name; 
 
exception 
when others then 
    return as_code; 
end;

/

