create FUNCTION          "FN_ADJUST_MVALUE2" ( ai_panel_cnt in number ) return number is 
    mvalue number := 0; 
begin 
    select mvalue 
    into mvalue 
    from tb_outlier_adjust2 
    where ai_panel_cnt >= fm_panel_cnt 
    and ai_panel_cnt <= to_panel_cnt; 
 
return mvalue; 
 
exception 
    when others then 
    return NULL; 
end;

/

