create FUNCTION          "FN_FAMILY_NUM" ( as_code in char ) return char is 
    family_cnt number; 
begin 
    select count(*) cnt 
    into family_cnt 
    from tb_family 
    where family_id = ( 
                        SELECT MAX(FAMILY_ID) 
                        FROM TB_FAMILY 
                        WHERE panel_id = as_code 
                      ); 
 
return family_cnt; 
 
exception 
when others then 
    return as_code; 
end;

/

