create FUNCTION        "FN_FBOOK_ENG" ( as_code in char ) return char is 
    eng_name varchar2(50):= NULL; 
begin 
    select eng
    into eng_name 
    from temp_jhlee_fbook_eng 
    where kor = as_code; 
if eng_name is null then 
    eng_name := as_code; 
end if; 
 
return eng_name; 
 
exception 
    when others then 
    return as_code; 
end;
/

