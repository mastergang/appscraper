create FUNCTION        "FN_AGECLS" ( ai_age in number ) return char is 
agecls_cd varchar2(02) := NULL; 
begin 
select  decode(sign(ai_age - 7 ), -1, '99', 
        decode(sign(ai_age - 19), -1, '11', 
        decode(sign(ai_age - 25), -1, '40', 
        decode(sign(ai_age - 30), -1, '50', 
        decode(sign(ai_age - 35), -1, '60', 
        decode(sign(ai_age - 40), -1, '70', 
        decode(sign(ai_age - 50), -1, '80', '90'))))))) 
        into agecls_cd 
        from dual; 
         
return agecls_cd; 
 
exception 
    when others then 
    return NULL; 
end;
/

