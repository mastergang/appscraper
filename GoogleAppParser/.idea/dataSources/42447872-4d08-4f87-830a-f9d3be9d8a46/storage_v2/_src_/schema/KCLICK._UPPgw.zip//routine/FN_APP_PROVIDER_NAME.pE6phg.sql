create FUNCTION          "FN_APP_PROVIDER_NAME" ( al_pro_id in number ) return char is 
    pro_name varchar(100) := NULL; 
begin 
    select pro_name 
    into pro_name 
    from tb_app_provider_name
    where pro_id = al_pro_id; 
 
return pro_name; 
 
end;

/

