create FUNCTION        "FN_TELECOM_NAME" ( as_code in char ) return char is 
    telecom_name varchar2(20):= NULL; 
begin 
    select code_name 
    into telecom_name 
    from tb_codebook 
    where meta_code = 'KC_TELE_CLS' 
    and code = as_code; 
if telecom_name is null then 
    telecom_name := as_code; 
end if; 
 
return telecom_name; 
 
exception 
    when others then 
    return as_code; 
end;
/

