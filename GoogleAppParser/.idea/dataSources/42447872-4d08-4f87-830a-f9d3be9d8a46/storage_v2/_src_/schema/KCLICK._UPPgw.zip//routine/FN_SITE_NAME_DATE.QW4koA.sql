create FUNCTION          "FN_SITE_NAME_DATE" ( al_site_id in number, check_date in date ) return char is 
    site_name varchar(40) := NULL; 
begin 
    select site_name 
    into site_name 
    from tb_site_info 
    where site_id = al_site_id and check_date > ef_time and check_date < exp_time; 
 
return site_name; 
 
end;

/

