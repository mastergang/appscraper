create FUNCTION        "FN_WEEK_STARTDAY" ( as_week in char ) return char is 
    week_date varchar2(8):= NULL; 
begin 
    /* 주코드를 날짜로 변환 */ 
    select start_date  
    into week_date 
    from tb_week_cat  
    where weekcode = as_week; 
 
return week_date; 
 
exception 
when others then 
    return '-1'; 
end;
/

