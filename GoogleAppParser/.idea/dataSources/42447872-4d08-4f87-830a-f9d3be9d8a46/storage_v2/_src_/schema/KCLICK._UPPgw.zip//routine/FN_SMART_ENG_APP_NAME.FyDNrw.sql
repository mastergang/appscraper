create FUNCTION          "FN_SMART_ENG_APP_NAME" ( al_smart_id in number ) return char is 
    eng_app_name varchar(200) := NULL; 
begin 
    select eng_app_name 
    into eng_app_name 
    from tb_smart_app_info 
    where smart_id = al_smart_id
    and   ef_time < sysdate
    and   exp_time > sysdate; 
 
return eng_app_name; 
 
end;

/

