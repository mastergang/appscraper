create FUNCTION          "FN_MONTH_LASTDAY" ( as_month in char ) return char is 
    month_date varchar2(8):= NULL; 
begin 
/* 월의 마지막날짜로 변환 */ 
    select to_char(last_day(to_date(as_month,'yyyymm')),'yyyymmdd') into month_date 
    from dual; 
 
return month_date; 
 
exception 
when others then 
    return '-1'; 
end;

/

