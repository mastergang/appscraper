create FUNCTION          "FN_ENCODE_STRING" ( string in char ) return char is 
    encode varchar2(2):= NULL; 
    return_code varchar2(26):= NULL; 
    code varchar2(1):=NULL; 
begin 
    for i in 1..length(string) loop 
        code:=lower(substr(string,i,1)); 
        if code='0' then encode := '6K'; 
        elsif code='1' then encode := 'B2'; 
        elsif code='2' then encode := '3M'; 
        elsif code='3' then encode := 'D8'; 
        elsif code='4' then encode := '8O'; 
        elsif code='5' then encode := 'F9'; 
        elsif code='6' then encode := '1Q'; 
        elsif code='7' then encode := 'H6'; 
        elsif code='8' then encode := '8S'; 
        elsif code='9' then encode := 'J9'; 
        elsif code='a' then encode := 'L2'; 
        elsif code='b' then encode := '0K'; 
        elsif code='c' then encode := 'M0'; 
        elsif code='d' then encode := 'J2'; 
        elsif code='e' then encode := '6N'; 
        elsif code='f' then encode := '2I'; 
        elsif code='g' then encode := 'O5'; 
        elsif code='h' then encode := 'H4'; 
        elsif code='i' then encode := '1P'; 
        elsif code='j' then encode := '5G'; 
        elsif code='k' then encode := 'Q3'; 
        elsif code='l' then encode := 'F2'; 
        elsif code='m' then encode := '2R'; 
        elsif code='n' then encode := '2E'; 
        elsif code='o' then encode := 'S2'; 
        elsif code='p' then encode := 'D1'; 
        elsif code='q' then encode := '4T'; 
        elsif code='r' then encode := '8C'; 
        elsif code='s' then encode := 'U9'; 
        elsif code='t' then encode := 'B4'; 
        elsif code='u' then encode := '7V'; 
        elsif code='v' then encode := '1A'; 
        elsif code='w' then encode := 'W9'; 
        elsif code='x' then encode := 'Y2'; 
        elsif code='y' then encode := '9X'; 
        elsif code='z' then encode := 'Z3'; 
        else encode := ''; 
        end if; 
    return_code:= return_code || encode; 
    end loop; 
 
return return_code; 
 
exception 
when others then 
    return '-1'; 
end;

/

