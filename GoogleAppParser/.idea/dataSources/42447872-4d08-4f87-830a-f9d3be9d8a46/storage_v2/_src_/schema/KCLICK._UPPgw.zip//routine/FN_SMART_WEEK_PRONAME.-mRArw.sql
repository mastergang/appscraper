create FUNCTION          "FN_SMART_WEEK_PRONAME" (as_weekcode in char, al_pro_id in number) return char is    
    provider_name varchar(100) := NULL; 
begin    
    select pro_name
    into provider_name 
    from tb_smart_provider_name_info
    where pro_id = al_pro_id
    and   ef_time <= to_date(fn_week_lastday(as_weekcode),'yyyymmdd')
    and   exp_time >= to_date(fn_week_lastday(as_weekcode),'yyyymmdd');
    
return provider_name;    
    
end;

/

