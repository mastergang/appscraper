create FUNCTION          "FN_BEFORE_WEEKCODE" ( as_weekcode in char, as_ago in number) 
return char is 
    f_week_no number := 0; 
    f_before4_weekcode varchar2(06) := NULL; 
    f_before_year varchar2(04) := NULL; 
    f_sig_year varchar2(04):= NULL; 
begin 
f_sig_year := substr(as_weekcode,1,4); 
f_week_no := to_number(substr(as_weekcode,5,2)) - as_ago; 
 
if ( f_week_no > 0 ) then 
    f_before4_weekcode := f_sig_year||lpad(to_char(f_week_no),2,'0'); 
else 
    f_before_year := to_char(to_date(f_sig_year||'0101','YYYYMMDD') -1,'YYYY'); 
    f_before4_weekcode := f_before_year||lpad(to_number(substr(fn_weekcode(f_before_year||'1231'),5,2))+f_week_no, 2,'0'); 
end if; 
 
return f_before4_weekcode; 
 
exception 
when others then 
    raise_application_error(-20001, 'f_get_before4_weekcode Etc Error :'||sqlerrm); 
end fn_before_weekcode;

/

