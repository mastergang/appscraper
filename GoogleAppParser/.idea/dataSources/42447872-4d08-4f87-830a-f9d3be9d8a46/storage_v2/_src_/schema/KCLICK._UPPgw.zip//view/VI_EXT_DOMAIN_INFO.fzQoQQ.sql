create view VI_EXT_DOMAIN_INFO as
SELECT a.site_id,
       domain_url,
       case
         when a.site_id = 1173
and    a.domain_url in (select path_url
        from   tb_section_info
        where  site_id = 1173
        and    section_id = 21
        and    exp_time > sysdate
        and    path_url like 'http://cafe%.daum.net' ) then
         case
           when translate(substr(a.domain_url, 12, instr(a.domain_url, '.daum.net')-12), 'A0123456789', 'A') is null then 'http://cafe%.daum.net'
           else a.domain_url
         end
         when a.site_id = 1173
            and    section_id=19
            and    a.domain_url like 'http://wwl%.hanmail.net' then 'http://wwl%.hanmail.net'

         when a.site_id = 1173
and    a.domain_url like 'http://wwl%.daum.net' then 'http://wwl%.daum.net'
         when a.site_id = 171
and    a.domain_url like 'http://kr.c%lub.yahoo.com' then 'http://kr.c%lub.yahoo.com'
         when a.site_id = 171
and    a.domain_url like 'http://kr.f%.mail.yahoo.com' then 'http://kr.f%.mail.yahoo.com'
         when a.site_id = 436
and    a.domain_url like 'http://hompy%.sayclub.com' then 'http://hompy%.sayclub.com'
         when a.site_id = 1124
and    a.domain_url like 'http://ms0%.hanafos.com' then 'http://ms0%.hanafos.com'
         when a.site_id = 175
and    a.domain_url in (select path_url
        from   tb_section_info
        where  site_id = 175
        and    section_id = 2
        and    exp_time > sysdate
        and    path_url like 'http://search%.dreamwiz.com' ) then 'http://search%.dreamwiz.com'
         when a.site_id = 166
and    a.domain_url like 'http://%hotmail%.com'
and    a.section_id = 19 then 'http://%hotmail%.com'
         when a.site_id = 1262
and    a.domain_url like 'http://www%.hompy.buddybuddy.co.kr' then 'http://www%.hompy.buddybuddy.co.kr'
         else a.domain_url
       end ext_domain_url,
       section_id
FROM   tb_domain_info a
WHERE  exp_time >= sysdate

/

