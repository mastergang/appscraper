create FUNCTION          "FN_PANEL_REGION" ( as_address in char ) return char is 
    REGION_CD varchar2(10):= NULL; 
begin 
    select CODE_ETC into REGION_CD 
    from   tb_codebook
    where  META_CODE = 'ADDRESS'
    and    length(code_etc) = 2
    and    as_address like substr(CODE_NAME,1,2)||'%';
 
return REGION_CD; 
 
exception 
when others then 
    return as_address; 
end;

/

