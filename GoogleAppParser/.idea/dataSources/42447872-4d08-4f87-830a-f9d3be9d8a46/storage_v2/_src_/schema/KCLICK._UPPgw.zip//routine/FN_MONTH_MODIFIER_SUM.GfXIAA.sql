create FUNCTION        "FN_MONTH_MODIFIER_SUM" ( as_monthcode in char ) return char is
    modifier number;
    total_netizen number;
    weekcode varchar(6);
    total_nfactor number;
begin
    select fn_valid_weekcode(as_monthcode)
    into weekcode
    from dual;

if(weekcode<'200108') then total_netizen := 12134395;
    elsif((weekcode>='200108') and (weekcode<='200120')) then total_netizen := 17275920;
    elsif((weekcode>='200121') and (weekcode<='200133')) then total_netizen := 18955854;
    elsif((weekcode>='200134') and (weekcode<='200146')) then total_netizen := 19634395;
    elsif((weekcode>='200147') and (weekcode<='200206')) then total_netizen := 19887480;
    elsif((weekcode>='200207') and (weekcode<='200219')) then total_netizen := 21317962;
    elsif((weekcode>='200220') and (weekcode<='200237')) then total_netizen := 21505029;
    elsif((weekcode>='200238') and (weekcode<='200250')) then total_netizen := 22337647;
    elsif((weekcode>='200251') and (weekcode<='200311')) then total_netizen := 22884169;
    elsif((weekcode>='200312') and (weekcode<='200324')) then total_netizen := 23658097;
    elsif((weekcode>='200325') and (weekcode<='200337')) then total_netizen := 24509055;
    elsif((weekcode>='200338') and (weekcode<='200411')) then total_netizen := 25007891;
    elsif((weekcode>='200412') and (weekcode<='200437')) then total_netizen := 26414464;
    elsif((weekcode>='200438') and (weekcode<='200511')) then total_netizen := 27867760;
    elsif((weekcode>='200538') and (weekcode<='200611')) then total_netizen := 29346634;
    elsif((weekcode>='200612') and (weekcode<='200637')) then total_netizen := 29677539;
    elsif((weekcode>='200638') and (weekcode<='200711')) then total_netizen := 29196962;
    elsif((weekcode>='200712') and (weekcode<='200737')) then total_netizen := 30611551;
    elsif((weekcode>='200738') and (weekcode<='200810')) then total_netizen := 31516623;
    elsif((weekcode>='200811') and (weekcode<='200837')) then total_netizen := 32251657;
    elsif((weekcode>='200838') and (weekcode<='200925')) then total_netizen := 32307171;
    elsif((weekcode>='200926') and (weekcode<='201025')) then total_netizen := 32340542;
    elsif((weekcode>='201026') and (weekcode<='201125')) then total_netizen := 32255868;
    else   total_netizen := 32005855;
end if;

    select sum(kc_n_factor)
    into total_nfactor
    from tb_month_panel_seg
    where monthcode = as_monthcode;
    modifier := total_netizen / total_nfactor;

return modifier;

exception
when others then
    return '-1';
end;
/

