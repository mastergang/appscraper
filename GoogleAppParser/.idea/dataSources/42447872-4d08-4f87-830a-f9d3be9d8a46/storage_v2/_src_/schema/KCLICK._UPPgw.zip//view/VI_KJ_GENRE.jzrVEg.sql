create view VI_KJ_GENRE as
    select APP_ID, fn_genre_name(APP_TYPE_CD2) genre
from   tb_app_info
where  APP_TYPE_CD='G'
and    ef_time < sysdate
and    exp_time > sysdate
and    app_id not in (
                        2725,1906,2639,2646,1686,2664,2685,2387,80,1649,1690,330,
                        1645,2165,2267,2270,2130,74,1521,2208,2361,1910,1855,1597,307,
                        1769,1924,2070,2382,1771,2300,2039,1758,2182,2440,2015,2136,385,
                        1535,1587,2121,2057,2241,2524,2531,2536,2544,2547,2548,2631
                     )
union all
select APP_ID,'저연령 RPG' genre
from tb_app_info
where APP_TYPE_CD='G'
and ef_time < sysdate
and exp_time > sysdate
and app_id in (
                2725,1906,2639,2646,1686,2664,2685,2387,80,1649,
                1690,330,1645,2165,2267,2270,2130,74,1521,2208,
                2361,1910,1855,1597,307,1769,1924,2070,2382,1771,
                2300,2039,1758,2182,2440,2015,2136,385,1535,1587,
                2121,2057,2241,2524,2531,2536,2544,2547,2548,2631
              )

/

