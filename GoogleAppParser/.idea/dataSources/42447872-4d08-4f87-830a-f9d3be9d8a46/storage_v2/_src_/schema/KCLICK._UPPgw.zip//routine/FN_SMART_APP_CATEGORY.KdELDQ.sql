create FUNCTION        "FN_SMART_APP_CATEGORY" ( AL_APP_CATEGORY_CD in varchar ) return char is   
    APP_CATEGORY_NAME varchar(100) := NULL;   
begin   
    select APP_CATEGORY_NAME   
    into APP_CATEGORY_NAME   
    from ( 
        select APP_CATEGORY_CD1 CATE_CD, APP_CATEGORY_NAME from TB_SMART_APP_CATEGORY_CD1 where exp_time > sysdate 
        union all 
        select APP_CATEGORY_CD2 CATE_CD, APP_CATEGORY_NAME from TB_SMART_APP_CATEGORY_CD2 where exp_time > sysdate
    ) 
    where CATE_CD = AL_APP_CATEGORY_CD;   
   
return APP_CATEGORY_NAME;   
   
end;
/

