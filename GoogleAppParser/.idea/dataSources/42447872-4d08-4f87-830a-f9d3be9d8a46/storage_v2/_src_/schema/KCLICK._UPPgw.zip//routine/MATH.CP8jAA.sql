create function math(expr in varchar) return number
as
        sql_stmt varchar(2000);
        rslt number;
begin
        sql_stmt := 'select ' || expr || ' from dual';
        execute immediate sql_stmt into rslt;
        return rslt;
end;
/

