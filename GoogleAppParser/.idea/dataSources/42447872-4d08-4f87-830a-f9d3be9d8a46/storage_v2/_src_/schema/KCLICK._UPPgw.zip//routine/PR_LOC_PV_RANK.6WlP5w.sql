create PROCEDURE          "PR_LOC_PV_RANK" 
            ( as_keycode  tb_week_cat.weekcode%TYPE, as_proc_type in char)
is
     total_netizen     number := 0;
     home_netizen      number := 0;
     biz_netizen       number := 0;

      /* Unique User Count Descanding 순으로 Select 한다. */
      cursor C_pv_week is
         select loc_site.site_id, loc_site.loc_cd,
                (pv_cnt_adj/uu_cnt_adj)*(reach_rate_adj*decode(loc_cd,'1', biz_netizen, home_netizen)/100)*total_site.total_pv_cnt/sum_loc_site.sum_pv_cnt
           from tb_week_loc_site loc_site,
                ( select site_id,
                         (pv_cnt_adj/uu_cnt_adj)*(reach_rate_adj*total_netizen/100) total_pv_cnt
                    from tb_week_site_sum
                   where weekcode = as_keycode
                     and uu_cnt_adj > 0
                ) total_site,
                ( select site_id,
                         sum((pv_cnt_adj/uu_cnt_adj) * ((reach_rate_adj* decode(loc_cd,'1', biz_netizen, home_netizen)/100)))
                         sum_pv_cnt
                    from tb_week_loc_site
                   where weekcode = as_keycode
                     and uu_cnt_adj > 0
                  group by site_id
                ) sum_loc_site
          where weekcode = as_keycode
            and loc_site.site_id = sum_loc_site.site_id
            and loc_site.site_id = total_site.site_id
            and sum_loc_site.sum_pv_cnt  > 0
            and loc_site.uu_cnt_adj > 0
            and loc_site.reach_rate_adj >= 1
	    and category_code2 < 'Z'
   	   order by loc_site.loc_cd,
                ((pv_cnt_adj/uu_cnt_adj)*(reach_rate_adj*decode(loc_cd,'1', biz_netizen, home_netizen)/100)*total_site.total_pv_cnt/sum_loc_site.sum_pv_cnt) desc;

      cursor C_pv_month is
         select loc_site.site_id, loc_site.loc_cd, (pv_cnt_adj/uu_cnt_adj)*(reach_rate_adj*decode(loc_cd, '1', biz_netizen, home_netizen)/100)*total_site.total_pv_cnt/sum_loc_site.sum_pv_cnt
	   from tb_month_loc_site loc_site,
                ( select site_id,
                         (pv_cnt_adj/uu_cnt_adj)*(reach_rate_adj*total_netizen/100) total_pv_cnt
                    from tb_month_site_sum
                   where monthcode = as_keycode
                     and uu_cnt_adj > 0
                ) total_site,
                ( select site_id,
                         sum((pv_cnt_adj/uu_cnt_adj) * ((reach_rate_adj* decode(loc_cd,'1', biz_netizen, home_netizen)/100)))
                         sum_pv_cnt
                    from tb_month_loc_site
                   where monthcode = as_keycode
                     and uu_cnt_adj > 0
                  group by site_id
                ) sum_loc_site
          where monthcode = as_keycode
            and loc_site.site_id = sum_loc_site.site_id
            and loc_site.site_id = total_site.site_id
            and sum_loc_site.sum_pv_cnt  > 0
            and loc_site.uu_cnt_adj > 0
            and loc_site.reach_rate_adj >= 1
	    and category_code2 < 'Z'
	  order by loc_site.loc_cd,
                ((pv_cnt_adj/uu_cnt_adj)*(reach_rate_adj*decode(loc_cd,'1', biz_netizen, home_netizen)/100)*total_site.total_pv_cnt/sum_loc_site.sum_pv_cnt) desc;

	c_site_id 	  tb_week_loc_site.site_id%type;
	c_loc_cd          tb_week_loc_site.loc_cd%type;
	c_pv_cnt_rate	  number := 0;

	s_overall_rank	  tb_week_loc_site.uu_overall_rank%type;
	d_rowcnt	  number := 0;
	sv_loc_cd	    tb_week_loc_site.loc_cd%type;
	sv_pv_cnt_rate	  number := 0;

    stop 	exception;

    /* Table에 uu rank 를 udate한다. */
    function f_update_pv_rank return number
    is
    begin
       if as_proc_type = 'W' then
         update kclick.tb_week_loc_site
            set pv_overall_rank = s_overall_rank
          where site_id = c_site_id
	    and loc_cd  = c_loc_cd
	    and weekcode = as_keycode;

      else
         update kclick.tb_month_loc_site
            set pv_overall_rank = s_overall_rank
          where site_id = c_site_id
	    and loc_cd  = c_loc_cd
	    and monthcode = as_keycode;

	  end if;

      return 0;
    exception
      When OTHERS then	           /* 기타 오라클 에러 */
         return -1;
    end f_update_pv_rank;

    function f_get_netizen_cnt return number
    is
         cat_proc_date date := null;
    begin
       if as_proc_type = 'W' then
          select proc_date
            into cat_proc_date
            from tb_week_cat
           where weekcode = as_keycode;
       else
          select proc_date
            into cat_proc_date
            from tb_month_cat
           where monthcode = as_keycode;
       end if;

       select sum(netizen_cnt)
         into total_netizen
         from tb_ri_seg
        where cat_proc_date >= ef_time
          and cat_proc_date <= exp_time;

       select sum(netizen_cnt)
         into home_netizen
         from tb_loc_ri_seg
        where cat_proc_date >= ef_time
          and cat_proc_date <= exp_time
          and loc_cd ='3';

       select sum(netizen_cnt)
         into biz_netizen
         from tb_loc_ri_seg
        where cat_proc_date >= ef_time
          and cat_proc_date <= exp_time
          and loc_cd ='1';

       return 0;
    exception
      When OTHERS then	           /* 기타 오라클 에러 */
         return -1;
    end f_get_netizen_cnt;

begin

    dbms_output.put_line('start pr_loc_pv_rank'||to_char(sysdate,'HH24:MI:SS'));

    if f_get_netizen_cnt < 0 then
       raise stop;
    end if;

    /* uu rank를 처리한다.  */
    if as_proc_type = 'W' then
        open C_pv_week;
    else
        open C_pv_month;
	end if;

    loop
	if as_proc_type = 'W' then
	   fetch C_pv_week into c_site_id, c_loc_cd, c_pv_cnt_rate;
	   if C_pv_week%NOTFOUND then
	      exit;
	   end if;
        else
	   fetch C_pv_month into c_site_id, c_loc_cd, c_pv_cnt_rate;
	   if C_pv_month%NOTFOUND then
	      exit;
	   end if;
        end if;

        /* 이전 record와 unique user count가 다르면 순위를 증가시킨다. */
	if nvl(sv_loc_cd,'x') != c_loc_cd then
	   d_rowcnt := 1;
	   s_overall_rank := 1;
           sv_loc_cd := c_loc_cd;
	   sv_pv_cnt_rate := c_pv_cnt_rate;
	else
	   d_rowcnt := d_rowcnt + 1;

	   if sv_pv_cnt_rate != c_pv_cnt_rate then
	      s_overall_rank := d_rowcnt;
              sv_pv_cnt_rate := c_pv_cnt_rate;
           end if;
        end if;

	if f_update_pv_rank < 0 then
	   raise stop;
        end if;

    end loop;

    if as_proc_type = 'W' then
       close C_pv_week;
    else
       close C_pv_month;
    end if;

    commit;

    dbms_output.put_line('after pr_loc_pv_rank'||to_char(sysdate,'HH24:MI:SS'));
   exception
     when STOP then
	   if C_pv_week%ISOPEN then
	      close C_pv_week;
	   elsif C_pv_month%ISOPEN then
	      close C_pv_month;
       end if;

	   rollback;
       raise_application_error(-20003, 'pr_loc_pv_rank  error');
end pr_loc_pv_rank;

/

