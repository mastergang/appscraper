create FUNCTION          "FN_ITRACK_VER" ( as_code in char ) return char is 
    itrack_version varchar2(5):= NULL; 
begin 
    select max(to_number(version)) 
    into itrack_version 
    from tb_itrack_version 
    where code = 'I' and panel_id = as_code; 
 
if itrack_version is null then 
    itrack_version := as_code; 
end if; 
 
return itrack_version; 
 
exception 
when others then 
    return as_code; 
end;

/

