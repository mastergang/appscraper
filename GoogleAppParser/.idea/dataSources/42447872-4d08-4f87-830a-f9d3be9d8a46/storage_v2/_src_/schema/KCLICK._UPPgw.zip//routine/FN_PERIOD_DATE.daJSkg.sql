create FUNCTION          "FN_PERIOD_DATE" (as_date1 in char,as_date2 in char) return char is 
period varchar2(4):= NULL; 
begin 
    /* 기간 반환 : end_date start_date */ 
    select trunc(to_date(as_date1,'yyyymmdd')+1-to_date(as_date2,'yyyymmdd')) into period from 
    dual; 
 
return period; 
 
exception 
when others then 
    return '-1'; 
end;

/

