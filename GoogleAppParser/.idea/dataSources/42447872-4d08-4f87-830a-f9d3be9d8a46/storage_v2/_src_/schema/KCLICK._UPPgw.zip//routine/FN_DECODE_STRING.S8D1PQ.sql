create FUNCTION          "FN_DECODE_STRING" ( string in char ) return char is 
    encode varchar2(2):= NULL; 
    return_code varchar2(26):= NULL; 
    code varchar2(1):=NULL; 
    i number :=1; 
begin 
    loop 
        encode:=substr(string,i,2); 
        if encode = '6K' then code := '0'; 
        elsif encode = 'B2' then code := '1'; 
        elsif encode = '3M' then code := '2'; 
        elsif encode = 'D8' then code := '3'; 
        elsif encode = '8O' then code := '4'; 
        elsif encode = 'F9' then code := '5'; 
        elsif encode = '1Q' then code := '6'; 
        elsif encode = 'H6' then code := '7'; 
        elsif encode = '8S' then code := '8'; 
        elsif encode = 'J9' then code := '9'; 
        elsif encode = 'L2' then code := 'a'; 
        elsif encode = '0K' then code := 'b'; 
        elsif encode = 'M0' then code := 'c'; 
        elsif encode = 'J2' then code := 'd'; 
        elsif encode = '6N' then code := 'e'; 
        elsif encode = '2I' then code := 'f'; 
        elsif encode = 'O5' then code := 'g'; 
        elsif encode = 'H4' then code := 'h'; 
        elsif encode = '1P' then code := 'i'; 
        elsif encode = '5G' then code := 'j'; 
        elsif encode = 'Q3' then code := 'k'; 
        elsif encode = 'F2' then code := 'l'; 
        elsif encode = '2R' then code := 'm'; 
        elsif encode = '2E' then code := 'n'; 
        elsif encode = 'S2' then code := 'o'; 
        elsif encode = 'D1' then code := 'p'; 
        elsif encode = '4T' then code := 'q'; 
        elsif encode = '8C' then code := 'r'; 
        elsif encode = 'U9' then code := 's'; 
        elsif encode = 'B4' then code := 't'; 
        elsif encode = '7V' then code := 'u'; 
        elsif encode = '1A' then code := 'v'; 
        elsif encode = 'W9' then code := 'w'; 
        elsif encode = 'Y2' then code := 'x'; 
        elsif encode = '9X' then code := 'y'; 
        elsif encode = 'Z3' then code := 'z'; 
        else code :=''; 
        end if; 
    return_code:= return_code || code; 
    i:=i+2; 
    exit when i > length(string); 
    end loop; 
 
return return_code; 
 
exception 
when others then 
    return '-1'; 
end;

/

