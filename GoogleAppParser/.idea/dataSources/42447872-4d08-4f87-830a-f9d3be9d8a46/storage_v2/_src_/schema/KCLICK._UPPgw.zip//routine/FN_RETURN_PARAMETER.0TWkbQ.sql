create FUNCTION          "FN_RETURN_PARAMETER" (full_url IN CHAR) RETURN CHAR IS 
BEGIN 
    IF full_url LIKE '%?%' THEN 
        RETURN SUBSTR(full_url, INSTR(full_url, '?') + 1); 
    ELSIF full_url LIKE '%#%' THEN 
        RETURN SUBSTR(full_url, INSTR(full_url, '#')); 
    END IF; 
 
RETURN ''; 
 
EXCEPTION 
WHEN OTHERS THEN 
    RETURN ''; 
END;

/

