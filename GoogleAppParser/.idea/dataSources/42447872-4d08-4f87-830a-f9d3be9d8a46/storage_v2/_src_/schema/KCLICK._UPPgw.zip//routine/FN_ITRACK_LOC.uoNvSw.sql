create FUNCTION          "FN_ITRACK_LOC" ( as_code in char ) return char is 
    itrack_loc varchar2(10); 
begin 
    select decode(sum(loc_cd), 1, '직장', 3, '집', '집/직장') loc 
    into itrack_loc 
    from tb_family 
    where panel_id = as_code
    and loc_cd in ('1','3')
    and family_id in (select max(family_id) from tb_family where panel_id = as_code)
    ; 
     
return itrack_loc; 
 
exception 
when others then 
    return as_code; 
end;

/

