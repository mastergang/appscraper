create FUNCTION          "FN_DECRYPT" (str VARCHAR2) RETURN VARCHAR2 
IS
key_string VARCHAR2(16):='kclick7200';
raw_key RAW(128):=UTL_RAW.CAST_TO_RAW(key_string);
encrypted_raw RAW(2048);
decrypted_raw RAW(2048);
return_raw VARCHAR2(100);
BEGIN
encrypted_raw := hextoraw(str);
dbms_obfuscation_toolkit.DESDecrypt(
	input => encrypted_raw,
	key => raw_key,
	decrypted_data => decrypted_raw
);
return_raw:=UTL_RAW.CAST_TO_VARCHAR2(decrypted_raw);
RETURN trim(return_raw);
exception 
    when others then 
    return null; 
END;

/

