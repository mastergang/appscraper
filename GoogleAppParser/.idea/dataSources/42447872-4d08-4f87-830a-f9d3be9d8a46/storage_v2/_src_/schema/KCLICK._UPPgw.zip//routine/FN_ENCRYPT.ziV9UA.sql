create FUNCTION          "FN_ENCRYPT" (str VARCHAR2) RETURN VARCHAR2 
IS

raw_input RAW(128);
key_string VARCHAR2(16):='kclick7200';
raw_key RAW(128):=UTL_RAW.CAST_TO_RAW(key_string);
encrypted_raw RAW(2048);
BEGIN
raw_input := UTL_RAW.CAST_TO_RAW(RPAD(str,FLOOR(LENGTHB(Str)/8+.9)*8));
dbms_obfuscation_toolkit.DESEncrypt(
	input => raw_input,
	key => raw_key,
	encrypted_data => encrypted_raw);
RETURN rawtohex(encrypted_raw);

exception 
    when others then 
    return null; 

END;


/

