create FUNCTION          "FN_MONTH_LOC_MODIFIER" ( as_monthcode in char, as_loc_cd in char ) return char is
    modifier number;
    last_access_date date;
begin
    select last_day(to_date(as_monthcode, 'yyyymm'))
    into last_access_date
    from dual;
    SELECT val1/val2
    INTO modifier
    FROM
    ( 
        SELECT sum(netizen_cnt) val1
        FROM tb_loc_ri_seg
        WHERE ef_time <= last_access_date
        AND exp_time > last_access_date
        AND loc_cd = as_loc_cd
    ) A,
    ( 
        SELECT sum(kc_n_factor) val2
        FROM tb_month_loc_panel_seg
        WHERE monthcode = as_monthcode
        AND loc_cd = as_loc_cd
    ) B;
    
return modifier;

exception
when others then
    dbms_output.put_line(sqlerrm);
return '-1';
end;

/

