create view VI_DUPLE_SECTION as
    select  code_id, 
        member_id site_id, 
        2 section_id, 
        section_id level3_section_id, 
        section_name, 
        level2_section_id, 
        level2_section_name, 
        level1_section_id, 
        level1_section_name 
from vi_new_section 
where (member_id, level1_section_id) in ((178,55082), (1173,45966), (177, 48007), (171, 58000)) 
union all 
select  code_id, 
        member_id, 
        7 section_id, 
        section_id level3_section_id, 
        section_name, 
        level2_section_id, 
        level2_section_name, 
        level1_section_id, 
        level1_section_name 
from vi_new_section 
where (member_id, level1_section_id) in ((178, 55210), (1173, 45922), (177, 48045), (171, 58198)) 
union all 
select  code_id, 
        member_id, 
        19 section_id, 
        section_id level3_section_id, 
        section_name, 
        level2_section_id, 
        level2_section_name, 
        level1_section_id, 
        level1_section_name 
from vi_new_section 
where (member_id, level1_section_id) in ((175, 46068)) 
union all 
select  code_id, member_id, 
        19 section_id, 
        section_id level3_section_id, 
        section_name, 
        level2_section_id, 
        level2_section_name, 
        level1_section_id, 
        level1_section_name 
from vi_new_section 
where (member_id, level2_section_id) in ((1173, 44748), (1206, 142076), (78, 55003)) 
union all 
select  code_id, 
        member_id, 
        19 section_id, 
        section_id level3_section_id, 
        section_name, 
        level2_section_id, 
        level2_section_name, 
        level1_section_id, 
        level1_section_name 
from vi_new_section 
where (member_id, section_id) in ((171, 58088)) 
union all 
select  code_id, 
        member_id, 
        16 section_id, 
        section_id level3_section_id, 
        section_name, 
        level2_section_id, 
        level2_section_name, 
        level1_section_id, 
        level1_section_name 
from vi_new_section 
where (member_id, level1_section_id) in ((171, 58219), (1173, 45032)) 
union all 
select  code_id, 
        member_id, 
        16 section_id, 
        section_id level3_section_id, 
        section_name, 
        level2_section_id, 
        level2_section_name, 
        level1_section_id, 
        level1_section_name 
from vi_new_section 
where (member_id, level2_section_id) in ((178, 55054))

/

