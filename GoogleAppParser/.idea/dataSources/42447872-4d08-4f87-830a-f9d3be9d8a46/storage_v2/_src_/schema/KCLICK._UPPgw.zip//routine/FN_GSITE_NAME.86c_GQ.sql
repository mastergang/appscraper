create FUNCTION          "FN_GSITE_NAME" ( al_site_id in number ) return char is 
    g_name varchar(40) := NULL; 
begin 
    select distinct g_name 
    into g_name 
    from tb_global_info 
    where g_site_id = al_site_id 
    and exp_time > sysdate; 
     
return g_name; 
 
end;

/

