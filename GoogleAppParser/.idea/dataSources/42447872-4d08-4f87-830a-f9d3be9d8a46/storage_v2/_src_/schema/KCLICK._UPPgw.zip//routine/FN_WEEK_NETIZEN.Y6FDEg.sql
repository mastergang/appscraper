create FUNCTION          "FN_WEEK_NETIZEN" ( as_weekcode in char ) return char is 
    modifier number; 
    total_netizen number; 
    weekcode varchar(6); 
    total_nfactor number; 
begin 
    weekcode := as_weekcode; 
    if(weekcode<'200108') then total_netizen := 12134395; 
    elsif((weekcode>='200108') and (weekcode<='200120')) then total_netizen := 17275920; 
    elsif((weekcode>='200121') and (weekcode<='200133')) then total_netizen := 18955854; 
    elsif((weekcode>='200134') and (weekcode<='200146')) then total_netizen := 19634395; 
    elsif((weekcode>='200147') and (weekcode<='200206')) then total_netizen := 19887480; 
    elsif((weekcode>='200207') and (weekcode<='200219')) then total_netizen := 21317962; 
    elsif((weekcode>='200220') and (weekcode<='200237')) then total_netizen := 21505029; 
    elsif((weekcode>='200238') and (weekcode<='200250')) then total_netizen := 22337647; 
    elsif((weekcode>='200251') and (weekcode<='200311')) then total_netizen := 22884169; 
    elsif((weekcode>='200312') and (weekcode<='200324')) then total_netizen := 23658097; 
    elsif((weekcode>='200325') and (weekcode<='200337')) then total_netizen := 24509055; 
    elsif((weekcode>='200338') and (weekcode<='200411')) then total_netizen := 25007891; 
    elsif((weekcode>='200412') and (weekcode<='200437')) then total_netizen := 26414464; 
    else total_netizen := 27867760; 
    end if; 
 
return total_netizen; 
 
exception 
when others then 
    return '-1'; 
end;

/

