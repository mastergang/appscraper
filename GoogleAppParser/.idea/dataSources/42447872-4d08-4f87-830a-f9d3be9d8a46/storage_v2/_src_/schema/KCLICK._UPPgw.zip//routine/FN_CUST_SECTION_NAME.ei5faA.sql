create FUNCTION          "FN_CUST_SECTION_NAME" ( al_code_id in number, al_site_id in number, al_section_id in number ) return char is 
    section_name varchar2(100); 
begin 
    select substr(min(section_name),1,100) 
    into section_name 
    from tbc_new_section 
    where code_id = al_code_id 
    and member_id = al_site_id 
    and section_id = al_section_id 
    and exp_time >= sysdate; 
     
return section_name; 
 
exception 
when others then 
    return null; 
end;

/

