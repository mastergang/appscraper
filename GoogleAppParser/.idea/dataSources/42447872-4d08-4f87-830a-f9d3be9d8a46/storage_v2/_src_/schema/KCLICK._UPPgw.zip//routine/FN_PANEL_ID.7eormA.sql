create FUNCTION          "FN_PANEL_ID" ( as_code in char ) return char is 
    panelid varchar(10):= NULL; 
begin 
    select panelid 
    into panelid 
    from tb_panel 
    where panel_no = as_code; 
 
if panelid is null then 
    panelid := as_code; 
end if; 
 
return panelid; 
 
exception 
when others then 
    return as_code; 
end;

/

