create FUNCTION        "MODIFIER" number;
    total_netizen number;
    total_nfactor number;
    weekcode number;
begin
    weekcode := as_weekcode;
	if(weekcode<'200108') then total_netizen := 12134395;
    elsif((weekcode>='200108') and (weekcode<='200120')) then total_netizen := 17275920;
    elsif((weekcode>='200121') and (weekcode<='200133')) then total_netizen := 18955854;
    elsif((weekcode>='200134') and (weekcode<='200146')) then total_netizen := 19634395;
    elsif((weekcode>='200147') and (weekcode<='200206')) then total_netizen := 19887480;
    elsif((weekcode>='200207') and (weekcode<='200219')) then total_netizen := 21317962;
    elsif((weekcode>='200220') and (weekcode<='200237')) then total_netizen := 21505029;
    elsif((weekcode>='200238') and (weekcode<='200250')) then total_netizen := 22337647;
    elsif((weekcode>='200251') and (weekcode<='200311')) then total_netizen := 22884169;
    elsif((weekcode>='200312') and (weekcode<='200324')) then total_netizen := 23658097;
    elsif((weekcode>='200325') and (weekcode<='200337')) then total_netizen := 24509055;
    elsif((weekcode>='200338') and (weekcode<='200411')) then total_netizen := 25007891;
    elsif((weekcode>='200412') and (weekcode<='200437')) then total_netizen := 26414464;
    elsif((weekcode>='200438') and (weekcode<='200511')) then total_netizen := 27867760;
    elsif((weekcode>='200512') and (weekcode<='200537')) then total_netizen := 28415433;
    elsif((weekcode>='200538') and (weekcode<='200611')) then total_netizen := 29346634;
    elsif((weekcode>='200612') and (weekcode<='200637')) then total_netizen := 29677539;
    elsif((weekcode>='200638') and (weekcode<='200711')) then total_netizen := 29196962;
    elsif((weekcode>='200712') and (weekcode<='200737')) then total_netizen := 30611551;
    elsif((weekcode>='200738') and (weekcode<='200810')) then total_netizen := 31516623;
    elsif((weekcode>='200811') and (weekcode<='200837')) then total_netizen := 32251657;
    elsif((weekcode>='200838') and (weekcode<='200925')) then total_netizen := 32307171;
    elsif((weekcode>='200926') and (weekcode<='201025')) then total_netizen := 32340542;
    elsif((weekcode>='201026') and (weekcode<='201125')) then total_netizen := 32255868;
    elsif((weekcode>='201126') and (weekcode<='201152')) then total_netizen := 32279315;
    elsif((weekcode>='201201') and (weekcode<='201213')) then total_netizen := 32005855;
    elsif((weekcode>='201214') and (weekcode<='201226')) then total_netizen := 32165472;
    elsif((weekcode>='201227') and (weekcode<='201239')) then total_netizen := 34610507;
    elsif((weekcode>='201240') and (weekcode<='201252')) then total_netizen := 34643388;
    elsif((weekcode>='201253') and (weekcode<='201312')) then total_netizen := 34917664;
    elsif((weekcode>='201313') and (weekcode<='201325')) then total_netizen := 34807589;
    elsif((weekcode>='201326') and (weekcode<='201338')) then total_netizen := 35321515;
    elsif((weekcode>='201339') and (weekcode<='201351')) then total_netizen := 35553134;
    else   total_netizen :=  36085110 ; 
    end if;

    select sum(kc_n_factor)
    into total_nfactor
    from tb_week_total_panel_seg
    where weekcode = as_weekcode;

modifier := total_netizen / total_nfactor;

return modifier;

exception
when others then
    return '-1';
end;
/

