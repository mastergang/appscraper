create FUNCTION          "FN_BROWSER_NAME" ( as_code in char ) return char is 
    browser_name varchar2(20):= NULL; 
begin 
    select code_name 
    into browser_name
    from tb_codebook 
    where meta_code = 'KC_BROWSER_KIND' 
    and code = nvl(as_code,'I'); 
if browser_name is null then 
    browser_name := as_code; 
end if; 
 
return browser_name; 
 
exception 
    when others then 
    return as_code; 
end;

/

