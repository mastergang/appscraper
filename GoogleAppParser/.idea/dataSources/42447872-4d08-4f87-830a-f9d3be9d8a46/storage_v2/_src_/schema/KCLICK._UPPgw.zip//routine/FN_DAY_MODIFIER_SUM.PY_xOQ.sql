create FUNCTION          "FN_DAY_MODIFIER_SUM" ( as_access_day in char ) return char is
    total_nfactor number;
begin
    SELECT var2/var1
    into total_nfactor
    FROM
    (
        SELECT sum(kc_n_factor) var1
        FROM tb_day_panel_seg
        WHERE access_day = as_access_day
    ),
    (
        SELECT sum(netizen_cnt) var2
        FROM tb_ri_seg
        WHERE to_char(ef_time ,'YYYYMMDD') <= as_access_day
        AND to_char(exp_time ,'YYYYMMDD') > as_access_day
    );

return total_nfactor;

exception
when others then
    return '-1';
end;

/

