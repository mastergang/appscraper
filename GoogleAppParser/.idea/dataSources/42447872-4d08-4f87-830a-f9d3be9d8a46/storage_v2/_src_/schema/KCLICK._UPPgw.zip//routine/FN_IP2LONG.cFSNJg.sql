create FUNCTION          "FN_IP2LONG" ( ip in varchar ) return number IS 
    num number := 0; 
BEGIN 
    SELECT  substr(ip, 1, instr(ip, '.', 1, 1)-1)*power(256,3) + 
            substr(ip, instr(ip, '.', 1, 1)+1, instr(ip, '.', 1, 2)-instr(ip, '.', 1, 1)-1)*power(256,2) + 
            substr(ip, instr(ip, '.', 1, 2)+1, instr(ip, '.', 1, 3)-instr(ip, '.', 1, 2)-1)*256 +substr(ip, instr(ip, '.', 1, 3)+1, length(ip)) num 
    INTO num 
    FROM dual; 
 
RETURN num; 
 
EXCEPTION 
WHEN OTHERS THEN 
    RETURN NULL; 
END;

/

