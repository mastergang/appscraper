create FUNCTION          "TO_BIN" ( p_dec in number ) return varchar2 is 
begin 
    return to_base( p_dec, 2 ); 
end to_bin;

/

