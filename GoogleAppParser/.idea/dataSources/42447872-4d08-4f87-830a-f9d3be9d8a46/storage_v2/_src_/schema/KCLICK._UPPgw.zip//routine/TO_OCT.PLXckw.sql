create FUNCTION        "TO_OCT" ( p_dec in number ) return varchar2 is 
begin 
    return to_base( p_dec, 8 ); 
end to_oct;
/

