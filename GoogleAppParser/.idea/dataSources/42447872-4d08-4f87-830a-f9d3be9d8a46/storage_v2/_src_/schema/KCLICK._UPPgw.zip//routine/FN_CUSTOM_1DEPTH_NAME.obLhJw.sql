create FUNCTION          "FN_CUSTOM_1DEPTH_NAME" ( as_kind in char, as_daycode in char, as_code in char ) return char is 
    section_name varchar2(100):= NULL; 
    begin 
    IF as_kind='monthcode' THEN
        select section_name
        INTO section_name
        from tbc_code_sec_sum c 
        where monthcode = as_daycode 
        and code_id = '113' 
        and SECTION_ID = 
        ( 
            select parent
            from tbc_code_sec_sum  b
            where monthcode = as_daycode  
            AND code_id = '113' 
            and SECTION_ID=as_code
        );
    ELSE    
        select section_name
        INTO section_name
        from tbc_week_code_sec_sum c 
        where weekcode = as_daycode 
        and code_id = '113' 
        and SECTION_ID = 
        ( 
            select parent
            from tbc_week_code_sec_sum  b
            where weekcode = as_daycode  
            AND code_id = '113' 
            and SECTION_ID=as_code
        );    
    END IF; 
    
    if section_name is null then 
    section_name := as_code; 
    end if; 

    return section_name; 
   
  exception 
when others then 
    return '-1'; 
end;

/

