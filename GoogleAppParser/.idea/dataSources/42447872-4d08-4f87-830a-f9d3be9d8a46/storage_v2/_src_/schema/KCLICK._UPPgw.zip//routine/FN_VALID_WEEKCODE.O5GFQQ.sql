create FUNCTION          "FN_VALID_WEEKCODE" ( as_yyyymm in char ) return char is 
    valid_weekcode varchar2(06):= NULL; 
begin 
    /* 해당월에 마지막일이 일요일(해당주의 마지막일)이면 해당주의 주코드 */ 
    /* 아니면, 해당월의 마지막 주코드 */ 
    select decode(to_char(last_day(to_date(as_yyyymm,'yyyymm')),'d'),'1',  
                substr(as_yyyymm,1,4)||lpad(to_char(fn_week_order_calc(to_char(last_day(to_date(as_yyyymm,'yyyymm')),'yyyymmdd'))),2,'0'),  
                substr(as_yyyymm,1,4)||lpad(to_char(fn_week_order_calc(to_char( last_day(to_date(as_yyyymm,'yyyymm'))  
                - ( to_char(last_day(to_date(as_yyyymm,'yyyymm')),'d')+ 5) ,'yyyymmdd'))),2,'0')) 
    into valid_weekcode 
    from dual; 
     
    return valid_weekcode; 
     
    exception 
    when others then 
        return '-1'; 
    end;

/

