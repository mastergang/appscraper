create FUNCTION          "FN_SMART_WEEK_COUNT" ( as_weekcode in char ) return char is  
    total_nfactor number;  
begin  
    select panel_cnt  
    into total_nfactor  
    from tb_smart_week_netizen_cnt  
    where weekcode = as_weekcode;  
  
return total_nfactor;  
  
exception  
when others then  
    return '-1';  
end;

/

