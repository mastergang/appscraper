create FUNCTION        "FN_RETURN_SEQUENCE_NEXTVAL" RETURN NUMBER IS  
    return_val NUMBER(20):=NULL; 
BEGIN 
    select temp_yjseo.NEXTVAL 
    into return_val 
    from dual 
    ;
 
return return_val; 
 
exception 
when others then 
    return return_val; 
end;
/

