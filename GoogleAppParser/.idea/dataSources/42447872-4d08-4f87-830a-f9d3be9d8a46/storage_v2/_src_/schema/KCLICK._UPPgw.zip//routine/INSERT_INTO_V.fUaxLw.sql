create procedure insert_into_v 
v_access_day in temp_jykim_env_itrack.access_day%type; 
v_panel_id in temp_jykim_env_itrack.panel_id%type; 
v_item_value in temp_jykim_env_itrack.item_value%type; 
v_register_date in temp_jykim_env_itrack.register_date%type; 
v_row_id in rowid; 
 
IS 
begin 
     v_row_id := mapp.row_id 
     v_access_day := mapp.access_day; 
     v_panel_id := mapp.panel_id; 
     v_register_date := mapp.register_date; 
     v_item_value := mapp.item_value;  
end;

/

