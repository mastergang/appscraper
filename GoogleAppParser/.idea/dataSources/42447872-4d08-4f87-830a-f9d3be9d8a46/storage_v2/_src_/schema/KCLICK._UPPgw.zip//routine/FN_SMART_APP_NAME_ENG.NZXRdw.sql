create FUNCTION          "FN_SMART_APP_NAME_ENG" ( al_smart_id in number ) return char is 
    app_name varchar(200) := NULL; 
begin 
    select app_eng_name 
    into  app_name 
    from  tb_smart_app_name_eng_info 
    where smart_id = al_smart_id; 
 
return app_name; 
 
end;

/

