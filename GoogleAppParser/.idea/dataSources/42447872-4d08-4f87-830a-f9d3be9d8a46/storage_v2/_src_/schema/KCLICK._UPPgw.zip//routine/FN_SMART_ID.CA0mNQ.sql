create FUNCTION          "FN_SMART_ID" ( al_package_name in varchar2 ) return number is
    smart_id number(22,9) := NULL;
begin
    select smart_id
    into smart_id
    from tb_smart_app_info
    where package_name = al_package_name
    and   ef_time < sysdate
    and   exp_time > sysdate;
    
return smart_id;

end;

/

