create FUNCTION          "FN_CATEGORY_REF2_NAME2_ENG" ( as_code in char ) return char is 
    category_name varchar2(100) := NULL; 
begin 
    select CODE_eng_NAME  
    into category_name 
    from 
    ( 
        select CODE_eng_NAME 
        from tb_category_ref2 
        where category_code = as_code 
        order by EF_TIME desc 
    ) 
    where rownum=1; 
 
if category_name is null then 
    category_name := as_code; 
end if; 
 
return category_name; 
 
exception 
when others then 
    return as_code; 
end;

/

