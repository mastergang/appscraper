create FUNCTION        "STR2TABLE" ( p_string in varchar2 ) return myArray as 
    l_data myArray := myArray(); 
    l_string long := p_string; 
    l_n number; 
begin 
while (l_string is not null) 
    loop 
        l_n := instr( l_string, '@' ); 
    if ( l_n = 0 ) then 
        l_n := length(l_string)+1; 
    end if; 
        l_data.extend; 
        l_data(l_data.count) := substr( l_string, 1, l_n-1 ); 
        l_string := substr( l_string, l_n+1 ); 
    end loop; 
 
return l_data; 
 
end;
/

