create FUNCTION          "FN_DAY_NFACTOR_SUM" ( as_access_day in char ) return char is 
    total_nfactor number; 
begin 
    select sum(kc_n_factor) 
    into total_nfactor 
    from tb_day_panel_seg 
    where access_day = as_access_day; 
 
return total_nfactor; 
 
exception 
when others then 
    return '-1'; 
end;

/

