create FUNCTION          "FN_SMART_PROVIDER_NAME" ( al_pro_id in number ) return char is    
    provider_name varchar(100) := NULL;    
begin    
    select pro_name    
    into provider_name    
    from tb_smart_provider_name_info    
    where pro_id = al_pro_id
    and   exp_time > sysdate
    and   ef_time  < sysdate;    
    
return provider_name;    
    
end;

/

