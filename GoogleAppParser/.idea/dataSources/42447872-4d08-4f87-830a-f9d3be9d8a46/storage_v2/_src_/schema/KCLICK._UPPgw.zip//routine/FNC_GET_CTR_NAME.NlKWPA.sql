create FUNCTION        "FNC_GET_CTR_NAME" (a_access_day char, a_panel_id char, a_nnc  char) 
return  CTR_TABLE  pipelined  -- 파이프라인 형식으로 CTR_TABLE 타입에 리턴 
is 
   a ctr := ctr(null,null,null);  -- 초기값.. ctr 구조체를 a 로 지정.. 
begin 
   for c1 in 
   ( 
        select access_day ctr_access_day, panel_id ctr_panel_id, nnc ctr_nnc 
        from 
        ( 
            select  access_day, 
                    panel_id, 
                    regexp_substr(naver_news_cast, '[^@]+', 1, level) nnc, 
                    level lv, 
                    lag(level, 1, 0) over (partition by access_day, panel_id order by level) lg 
            from 
            ( 
                select  a_access_day access_day, a_panel_id panel_id, a_nnc naver_news_cast 
                from dual 
            ) 
            connect by regexp_substr(naver_news_cast, '[^@]+', 1, level) is not null 
        ) 
        where lv != lg 
   ) 
 
   loop 
 
       a.ctr_access_day := c1.ctr_access_day; 
       a.ctr_panel_id := c1.ctr_panel_id; 
       a.ctr_nnc := c1.ctr_nnc; 
 
       pipe row(a);   -- 패치된 값을 저장.. 
 
   end loop; 
 
   return; 
 
   exception when no_data_found then 
     begin 
       a := ctr('','',''); 
       pipe row(a); 
     end; 
 
   return; 
 
end;
/

