create FUNCTION        "FN_TEST_AGE" ( ai_age  in number ) return char is 
   agecls_cd varchar2(04) := NULL; 
begin 
    select decode(sign(ai_age - 20), -1, '10대', 
				  decode(sign(ai_age - 30), -1, '20대', 
				  decode(sign(ai_age - 40), -1, '30대', 
				  decode(sign(ai_age - 50), -1, '40대', 
				  decode(sign(ai_age - 60), -1, '50대', 
                  '60대'))))) 
	  into agecls_cd 
	  from dual; 
 
    return agecls_cd; 
 
exception 
    
when others then 
    return NULL; 
end;
/

