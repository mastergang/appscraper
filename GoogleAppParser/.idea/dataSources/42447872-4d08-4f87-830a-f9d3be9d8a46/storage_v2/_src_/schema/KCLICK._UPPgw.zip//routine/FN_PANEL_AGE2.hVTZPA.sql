create FUNCTION          "FN_PANEL_AGE2" ( JUBUN IN VARCHAR2 ) return number deterministic is      
  V_AGE NUMBER; 
 
BEGIN 
 
    IF SUBSTR(JUBUN, 7,1) IN(1,2)   
 
      THEN V_AGE := EXTRACT(YEAR FROM SYSDATE) - (SUBSTR(JUBUN,1,2)+1900); 
 
    ELSE V_AGE := EXTRACT(YEAR FROM SYSDATE) - (SUBSTR(JUBUN,1,2)+2000); 
 
    END IF;
    

    IF V_AGE >= 60 THEN
        V_AGE := 60;
    ELSIF  V_AGE > 50 THEN
        V_AGE := 50;
    ELSIF  V_AGE >= 40 THEN
        V_AGE := 40;     
    ELSIF  V_AGE >= 30 THEN
        V_AGE := 30;      
    ELSIF  V_AGE >= 20 THEN
        V_AGE := 20;
    ELSE 
        V_AGE := 10; 
    END IF;
    

 
    RETURN V_AGE; 
 
END;

/

