create FUNCTION          "FN_FVALUE2" ( ai_panel_cnt in number ) return number is 
    fvalue number := 0; 
begin 
    select fvalue 
    into fvalue 
    from tb_outlier_fvalue2 
    where ai_panel_cnt >= fm_panel_cnt 
    and ai_panel_cnt <= to_panel_cnt; 
 
return fvalue; 
 
exception 
when others then 
    return NULL; 
end;

/

