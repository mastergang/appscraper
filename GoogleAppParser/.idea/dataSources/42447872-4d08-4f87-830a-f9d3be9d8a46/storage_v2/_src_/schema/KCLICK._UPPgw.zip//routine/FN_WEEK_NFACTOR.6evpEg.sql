create FUNCTION          "FN_WEEK_NFACTOR" ( as_weekcode in char ) return char is 
    total_nfactor number; 
begin 
    select total_nfactor 
    into total_nfactor 
    from tb_week_modifier 
    where weekcode = as_weekcode; 
 
return total_nfactor; 
 
exception 
when others then 
    return '-1'; 
end;

/

