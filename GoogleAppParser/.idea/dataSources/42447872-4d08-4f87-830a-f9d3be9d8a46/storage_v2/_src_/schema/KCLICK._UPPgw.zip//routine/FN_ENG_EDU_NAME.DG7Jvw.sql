create FUNCTION          "FN_ENG_EDU_NAME" ( as_code in char ) return char is 
    edu_name varchar2(20):= NULL; 
begin 
    select code_etc 
    into edu_name 
    from tb_codebook 
    where meta_code = 'ENG_EDU_CLS' 
    and code = as_code; 
 
if edu_name is null then 
    edu_name := as_code; 
end if; 
 
return edu_name; 
 
exception 
when others then 
    return as_code; 
end;

/

