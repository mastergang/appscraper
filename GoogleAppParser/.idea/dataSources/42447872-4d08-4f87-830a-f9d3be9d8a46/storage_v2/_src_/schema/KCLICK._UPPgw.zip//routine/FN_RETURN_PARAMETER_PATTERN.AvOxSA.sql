create FUNCTION          "FN_RETURN_PARAMETER_PATTERN" (full_url IN CHAR) RETURN CHAR IS 
BEGIN 
    RETURN fn_return_pattern(fn_return_parameter(full_url)); 
END;

/

