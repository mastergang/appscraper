create FUNCTION          "FN_ADDRKEY_NAME" ( as_code in char ) return char is 
    addrkey_name varchar2(30):= NULL; 
begin 
    select code_name 
    into addrkey_name 
    from tb_codebook 
    where meta_code = 'ADDRKEY' 
    and code = as_code; 
if addrkey_name is null then 
    addrkey_name := as_code; 
end if; 
 
return addrkey_name; 
 
exception 
    when others then 
    return as_code; 
end;

/

