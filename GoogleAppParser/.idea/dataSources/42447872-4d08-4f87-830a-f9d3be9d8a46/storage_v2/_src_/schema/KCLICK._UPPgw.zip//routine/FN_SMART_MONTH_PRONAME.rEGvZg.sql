create FUNCTION          "FN_SMART_MONTH_PRONAME" (as_monthcode in char, al_pro_id in number) return char is    
    provider_name varchar(100) := NULL; 
begin    
    select pro_name
    into provider_name 
    from tb_smart_provider_name_info
    where pro_id = al_pro_id
    and   ef_time <= to_date(fn_month_lastday(as_monthcode),'yyyymmdd')
    and   exp_time >= to_date(fn_month_lastday(as_monthcode),'yyyymmdd');
    
return provider_name;    
    
end;

/

