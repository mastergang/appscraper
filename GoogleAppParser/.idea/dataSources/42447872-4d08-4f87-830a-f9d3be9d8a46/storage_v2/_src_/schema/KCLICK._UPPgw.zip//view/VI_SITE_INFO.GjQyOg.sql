create view VI_SITE_INFO as
select  site_id,
        site_name,
        url_link,
        category_code1,
        category_code2,
        category_code3
from tb_site_info
where ef_time <= sysdate
and exp_time >= sysdate

/

